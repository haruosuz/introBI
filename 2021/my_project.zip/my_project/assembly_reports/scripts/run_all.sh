#!/bin/bash
set -e
set -u
set -o pipefail

# start
echo; echo "[$(date)] $0 job has been started."

# Print operating system characteristics
echo; echo "[$(date)] OS, version information"
uname -a
#sw_vers

# Creating directories
mkdir -p ./{analysis,data,scripts}

# downloading metadata
bash scripts/get_assembly_summary.sh

# create a variable and assign it a value with (do not use spaces around the equals sign!):
metadata="assembly_summary_genbank.txt"
metadata="assembly_summary_refseq.txt"

echo; echo "[$(date)] downloading genome data (GFF files)"
organism_name="coronavirus"
#organism_name="Escherichia coli str. K-12 substr. MG1655|Escherichia coli O157:H7 str. Sakai"
bash scripts/get_gff.sh "$metadata" "$organism_name"

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

# Let's run the driver script in the project's main directory with:
(time bash scripts/run_all.sh &) >& log.$(date +%F).txt

# Use `tail -f` to constantly monitor files (use Control-C to stop)
tail -f log.$(date +%F).txt

#__COMMENT_OUT__


