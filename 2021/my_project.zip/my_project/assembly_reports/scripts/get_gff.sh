#!/bin/bash
set -euo pipefail

# create a variable and assign it a value with (do not use spaces around the equals sign!):
metadata="assembly_summary_genbank.txt"
metadata="assembly_summary_refseq.txt"
metadata=$1

# List the ftp_path (column 20) for the assemblies of interest:
refseq_category="reference genome"
#refseq_category="representative genome"
#refseq_category="."

organism_name="coronavirus"
#organism_name="Escherichia coli str. K-12 substr. MG1655|Escherichia coli O157:H7 str. Sakai"
#organism_name="."
organism_name=$2

assembly_level="Complete Genome"
#assembly_level="."

echo; echo "# 5  refseq_category # 12  assembly_level # 8  organism_name"
cat $metadata | awk -F "\t" '$5 ~ /'"$refseq_category"'/ && $8 ~ /'"$organism_name"'/ && $11=="latest" && $12 ~ /'"$assembly_level"'/ {print $0}' | cut -f8

cat $metadata | awk -F "\t" '$5 ~ /'"$refseq_category"'/ && $8 ~ /'"$organism_name"'/ && $11=="latest" && $12 ~ /'"$assembly_level"'/ {print $20}' > ftpdirpaths

# Append the filename of interest, in this case "*_genomic.gff.gz" to the FTP directory names.
cat ftpdirpaths | awk 'BEGIN{FS=OFS="/";filesuffix="genomic.gff.gz"}{ftpdir=$0;asm=$10;file=asm"_"filesuffix;print ftpdir,file}' > ftpfilepaths

# NCBI provides a MD5 checksum file in this directory called "md5checksums.txt":  
cat ftpdirpaths | awk 'BEGIN {FS=OFS="/"} {print $0,"md5checksums.txt"}' ftpdirpaths >> ftpfilepaths

# Use the "ftpfilepaths" file as input to `wget` to download:  
# --directory-prefix=prefix --input-file=file
MYDIR=data/gff
mkdir -p "${MYDIR}"
wget -P "${MYDIR}" -i ftpfilepaths

# see the newest files
ls -lrt ${MYDIR}

# compare our checksum values with those in "md5checksums.txt" using the md5 program:
#md5 ${MYDIR}/*.gz # Mac
#md5sum ${MYDIR}/*.gz # Linux
echo; echo "md5checksums.txt"
grep "_genomic.gff.gz" ${MYDIR}/md5checksums.txt*

# `basename` strips paths and a suffix (e.g., extension) from filenames
# decompress files with the command `gunzip`:
#for file in ${MYDIR}/*.gff.gz; do gunzip -c $file > ${MYDIR}/$(basename $file .gz); done
#ls -lh ${MYDIR}/*.gff*

: '

metadata="assembly_summary_refseq.txt"
organism_name="coronavirus"
(time bash scripts/get_gff.sh "$metadata" "$organism_name" &) >& log.get_gff.$(date +%F).txt

'
