#!/bin/bash
set -euo pipefail

echo; echo "[] Getting metadata from ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/"
# Recursive downloading can be useful for downloading all files of a certain type from a page.
# wget --background --accept "*.txt,*.txt.gz" --no-directories --recursive --no-parent --level=1 $URL
#wget -o wget-log.txt -A "*.txt,*.txt.gz" -nd -r -np ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/
#wget ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/assembly_summary_genbank.txt
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/assembly_summary_refseq.txt

# create a variable and assign it a value with (do not use spaces around the equals sign!):
metadata="assembly_summary_genbank.txt"
metadata="assembly_summary_refseq.txt"

# Inspecting data
ls -l $metadata
grep "^#" $metadata | tail -n 1 | tr "\t" "\n" | nl

echo; echo "[] 5  refseq_category"
grep -v "^#" $metadata | cut -f5 | sort | uniq -c

echo; echo "[] 12  assembly_level"
grep -v "^#" $metadata | cut -f12 | sort | uniq -c

: '

(time bash scripts/get_assembly_summary.sh &) >& log.get_assembly_summary.$(date +%F).txt

'
