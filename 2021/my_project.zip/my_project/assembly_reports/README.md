Haruo Suzuki  
Last Update: 2021-10-23

----------

# ASSEMBLY_REPORTS Project
Project started 2021-10-23.  

Using the assembly summary report files to find the sequence and annotation of my genome of interest.

## updates

- 2021-10-23
  - Downloaded metadata from <ftp.ncbi.nlm.nih.gov/genomes/ASSEMBLY_REPORTS/>
  - Downloaded coronavirus reference genomes

## project directories
```
assembly_reports/
 README.md: project documentation
 scripts/: contains shell scripts
 data/: contains metadata and genome data
 analysis/: contains results of data analyses
```

## scripts

Let's run the driver script in the project's main directory `assembly_reports/` with:

    bash scripts/run_all.sh > log.$(date +%F).txt 2>&1 &

The shell script `scripts/run_all.sh` automatically carries out the entire steps: creating directories (`data/` and `analysis/`), 
running the shell scripts
for downloading metadata `scripts/get_assembly_summary.sh`, and 
for downloading genome data `scripts/get_gff.sh` (generating the output files `data/gff/*`).

## data

Coronavirus reference genomes (Complete Genome) were downloaded.

Data downloaded on 2021-10-23 from 
```
https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/864/885/GCF_000864885.1_ViralProj15500
https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/901/155/GCF_000901155.1_ViralProj183710
https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/009/858/895/GCF_009858895.2_ASM985889v3
```
into `data/gff/`:
```
data/gff/GCF_000864885.1_ViralProj15500_genomic.gff.gz
data/gff/GCF_000901155.1_ViralProj183710_genomic.gff.gz
data/gff/GCF_009858895.2_ASM985889v3_genomic.gff.gz

# MD5 Checksums
MD5 (data/gff/GCF_000864885.1_ViralProj15500_genomic.gff.gz) = 00d51a25cc471a16d484f80a824f45a1
MD5 (data/gff/GCF_000901155.1_ViralProj183710_genomic.gff.gz) = e0e5254a21f7af954aefe76b8072b314
MD5 (data/gff/GCF_009858895.2_ASM985889v3_genomic.gff.gz) = 0a2c6dca211847627509d4d618999513
```

## analysis

### assembly_summary_refseq.txt

```
# 5  refseq_category
226010 na
  69 reference genome
16223 representative genome

# 12  assembly_level
4776 Chromosome
35311 Complete Genome
122342 Contig
79873 Scaffold
```

### run environment

#### Haruo Suzuki's Mac OS X

```
$uname -a
Darwin haruos-MacBook-Pro-US.local 20.6.0 Darwin Kernel Version 20.6.0: Mon Aug 30 06:12:21 PDT 2021; root:xnu-7195.141.6~3/RELEASE_X86_64 x86_64

$sw_vers
ProductName:	macOS
ProductVersion:	11.6
BuildVersion:	20G165

```

## references
- [GFF format](http://genome.ucsc.edu/FAQ/FAQformat.html#format3)
- <https://www.ddbj.nig.ac.jp/ddbj/features.html>
- <https://www.ddbj.nig.ac.jp/ddbj/features-e.html>
- [DATA SCIENCE FOR BIOINFORMATICS [DS2] 2021](https://github.com/haruosuz/introBI/tree/master/2021)
  - [Using Pandoc to Render Markdown to HTML](https://github.com/haruosuz/introBI/tree/master/2021#using-pandoc-to-render-markdown-to-html)
```
FILE=README.md
pandoc --from markdown --to html ${FILE} > ${FILE}.html
```
- <https://github.com/haruosuz/bioinfo/blob/master/2019/CaseStudy.md#ncbi-assembly_reports>
- <https://github.com/haruosuz/DS4GD/blob/master/2018giga/CaseStudy.md#ncbi-assembly_reports>
- <https://github.com/haruosuz/introBI/blob/master/2018/CaseStudy.md#ncbi-assembly_reports>
- <https://github.com/haruosuz/introBI/blob/master/2018/CaseStudy.md#2018-11-27>




