#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### Writing and Applying Functions to Lists with lapply() and sapply()
#' **8.3.10　lapply()とsapply()関数を使って、リストに関数を適用する**
#' 
#' #### Digression: Debugging R Code
#' **8.3.10.3 R コードのデバッグ**

foo <- function(x) {
  a<-2
  browser()
  y<-x+a
  return(y)
}

foo(1)

bar <- function(x) x + "1"
bar(2)

options(error=recover)
bar(2)

options(error=NULL)

?browser
?debug
?traceback
?recover
