#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### Working with Strings
#' **8.3.13　文字列の操作**
#' 

length("AGCTAG")
nchar(c("AGCTAG", "ATA", "GATCTGAG", ""))

re_sites <- c("CTGCAG", "CGATCG", "CAGCTG", "CCCACA")
grep(pattern="CAG", x=re_sites)

grep(pattern="CT[CG]", x=re_sites)
#grep(pattern="CT[CG]", x=re_sites, perl=FALSE, fixed=FALSE)

chrs <- c("chrom6", "chr2", "chr6", "chr4", "chr1", "chr16", " chrom8")
grep(pattern="[^\\d]6", x=chrs, perl=TRUE)
chrs[grep(pattern="[^\\d]6", x=chrs, perl=TRUE)]
help(regex)

#' > ###### The Double Backslash

regexpr(pattern="[^\\d]6", text=chrs, perl=TRUE)

pos <- regexpr(pattern="\\d+", text=chrs, perl=TRUE)
pos
substr(x = chrs, start = pos, stop = pos + attributes(pos)$match.length)

sub(pattern="Watson", replacement="Watson, Franklin,", 
    x="Watson and Crick discovered DNA's structure.")

sub(pattern="gene=(\\w+)", replacement="\\1", x="gene=LEAFY", perl=TRUE)
sub(pattern=">[^ ]+ *(.*)", replacement="\\1", x=">1 length=301354135 type=dna")
sub(pattern=".*(\\d+|X|Y|M)", replacement="chr\\1", x="chr19", perl=TRUE)
#sub(pattern=" *[chrom]+(\\d+|X|Y|M) *", replacement="chr\\1", x=c("chr19", "chrY"), perl=TRUE)
sub(pattern=" *[chrom]+(\\d+|X|Y|M) *", replacement="chr\\1", x=c("chr19", "chromY"), perl=TRUE)

#' > ###### Friendly Functions for Loud Code  
?stopifnot()
?stop()
?warning()
?message()  
#options(warn=2)
#options(warn=0)
#' > 

paste("chr", c(1:22, "X", "Y"), sep="")
#paste("chr", c(1:22, "X", "Y"), sep="", collapse="|")

#' > ###### Extracting Multiple Values from a String  
region <- "chr10:158395-172881"
chunks <- sub("(chr[\\d+MYX]+):(\\d+)-(\\d+)", "\\1;;\\2;;\\3", region, perl=TRUE)
strsplit(chunks, ";;")
#' > 

leafy <- "gene=LEAFY;locus=2159208;gene_model=AT5G61850.1"
strsplit(leafy, ";")
