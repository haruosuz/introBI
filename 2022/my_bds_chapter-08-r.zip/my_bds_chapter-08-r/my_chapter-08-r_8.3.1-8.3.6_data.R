#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' - https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r
#' 
#' ### Loading Data into R
#' **8.3.1　データをRに読み込ませる**
getwd()
#setwd("~/bds-files/chapter-08-r") # path to this chapter's directory in the Github repository.
#' 
#' ----------
#' 
#' **LARGE GENOMICS DATA INTO R: COLCLASSES, COMPRESSION, AND MORE**
# read.table(file, colClasses = "NULL", nrows = -1)
# fread {data.table}
#' 
#' ----------
#' 
#help(read.table)
d <- read.csv("Dataset_S1.txt")
#' [R now uses a `stringsAsFactors = FALSE` default](https://stat.ethz.ch/R-manual/R-devel/doc/html/NEWS.html)
#' 
#' Table 8-4. Commonly used read.csv() and read.delim() arguments
#' 
#' ----------
#' 
#' **GETTING DATA INTO SHAPE**
#' 
#' Table 8-5. A gene expression counts table by tissue in wide format
#' 
#' Table 8-6. A gene expression counts table by tissue in long format
#' 
#' - http://had.co.nz/reshape/
#' 
#' ----------
#' 
#' ### Exploring and Transforming Dataframes
#' **8.3.2　データフレームの探索と変換**

head(d, n=3)

nrow(d)
ncol(d)
dim(d)

colnames(d) # row.names(d)

colnames(d)[12] # original name
colnames(d)[12] <- "percent.GC"
colnames(d)[12] # after change

#' > ###### Creating Dataframes from Scratch
x <- sample(1:50, 300, replace=TRUE)
y <- 3.2*x + rnorm(300, 0, 40)
d_sim <- data.frame(y=y, x=x)
#' > 

#d$depth
mean(d$depth)
summary(d$depth)

# dataframes use two indexes separated by a comma: df[row, col].
head(d[ , 1:2])
head(d[, c("start", "end")])
d[1, c("start", "end")]
d[1, ]
d[2, 3]

#' > ###### Fragile Code and Accessing Rows and Columns in Dataframes

head(d[, "start", drop=FALSE])

#' - https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r

d$cent <- d$start >= 25800000 & d$end <= 29700000

table(d$cent)

sum(d$cent)

d$diversity <- d$Pi / (10*1000) # rescale, removing 10x and making per bp
summary(d$diversity)

#' ### Exploring Data Through Slicing and Dicing: Subsetting Dataframes
#' **8.3.3　スライシングとダイシングによるデータの探索：データフレームのサブセット化**

summary(d$total.SNPs)

#d$total.SNPs >= 85

d[d$total.SNPs >= 85, ]

d[d$Pi > 16 & d$percent.GC > 80, ]

d[d$Pi > 16 & d$percent.GC > 80, c("start", "end", "depth", "Pi")]

d[d$Pi > 16 & d$percent.GC > 80, c("start", "end", "Pi", "depth")]

#d$percent.GC[d$Pi > 16]

summary(d$depth[d$percent.GC >= 80])
summary(d$depth[d$percent.GC < 80])

sum(d$percent.GC >= 80)

summary(d$Pi[d$cent])
summary(d$Pi[!d$cent])

#d$Pi > 3
#which(d$Pi > 3)

which(d$Pi > 10)[1:4]

d[which.min(d$total.Bases),]
d[which.max(d$depth),]

#d[d$Pi > 16 & d$percent.GC > 80, ]
subset(d, Pi > 16 & percent.GC > 80)

subset(d, Pi > 16 & percent.GC > 80, c(start, end, Pi, percent.GC, depth))

#' ### Exploring Data Visually with ggplot2 I: Scatterplots and Densities
#' **8.3.4　ggplot2によるデータ探索の可視化（I）：ScatterplotsとDensities**
#' 
#' - https://ggplot2.tidyverse.org/reference/
#' 
#install.packages("ggplot2")
library(ggplot2)

d$position <- (d$end + d$start) / 2
ggplot(d) + geom_point(aes(x=position, y=diversity))

#' Figure 8-1. ggplot2 scatterplot nucleotide diversity by position for human chromosome 20
#' 
#' > ###### Axis Labels, Plot Titles, and Scales
#p <- ggplot(d) + geom_point(aes(x=position, y=diversity))
#p + xlab("chromosome position (basepairs)") + ylab("nucleotide diversity")
#' > 

# Example 8-2. Including aes() in ggplot()
#ggplot(d, aes(x=position, y=diversity)) + geom_point()

# Example 8-3. A simple diversity scatterplot with ggplot2
ggplot(d) + geom_point(aes(x=position, y=diversity, color=cent))

#' Figure 8-2. ggplot2 scatterplot nucleotide diversity by position coloring by whether windows are in the centromeric region

ggplot(d) + geom_point(aes(x=position, y=diversity), alpha=0.01)

#' Figure 8-3. Using transparency to address overplotting

ggplot(d) + geom_density(aes(x=diversity), fill="black")

#' Figure 8-4. Density plot of diversity

ggplot(d) + geom_density(aes(x=diversity, fill=cent), alpha=0.4)

#' Figure 8-5. Densities of diversity, colored by whether a window is in the centromere or not
#' 
#' ### Exploring Data Visually with ggplot2 II: Smoothing
#' **8.3.5　ggplot2によるデータ探索の可視化（II）：平滑化**

ggplot(d, aes(x=depth, y=total.SNPs)) + geom_point() + geom_smooth()

#' Figure 8-6. A scatterplot (demonstrating overplotting) and GAM smoothing curve illustrating how total number of SNPs in a window depends on sequencing depth

#help(stat_smooth)

ggplot(d, aes(x=percent.GC, y=depth)) + geom_point() + geom_smooth()

#' Figure 8-7. A scatterplot and GAM smoothing curve show a relationship between extreme GC content windows and sequencing depth
#' 
#' ### Binning Data with cut() and Bar Plots with ggplot2
#' **8.3.6　cut()によるデータのビニングとggplot2を使った棒グラフの描画**
#' 
#' Example 8-4. Using cut() to bin GC content
d$GC.binned <- cut(d$percent.GC, breaks=5)
#d$GC.binned

table(d$GC.binned)

#cut(d$percent.GC, breaks=c(0, 25, 50, 75, 100))

#x <- d$percent.GC; breaks <- c(0, 25, 50); any(is.na(cut(x, breaks)))

ggplot(d) + geom_bar(aes(x=GC.binned))
ggplot(d) + geom_bar(aes(x=percent.GC))
ggplot(d) + geom_histogram(aes(x=percent.GC), bins = 30) # footnote
#' Figure 8-8. ggplot2’s geom_bar() used to visualize the GC.binned column we created with cut(), and the numeric percent.GC column using its own binning scheme

ggplot(d) + geom_density(aes(x=depth, linetype=GC.binned), alpha=0.5)
#' Figure 8-9. Density plots of depth, grouped by GC content bin
#ggplot(d) + geom_density(aes(x=Pi, linetype=GC.binned), alpha=0.5)
#ggplot(d) + geom_density(aes(x=total.SNPs, linetype=GC.binned), alpha=0.5)

#' > ###### Finding the Right Bin Width
ggplot(d) + geom_bar(aes(x=Pi), binwidth=1) + scale_x_continuous(limits=c(0.01, 80))
#' >
#' 
#' - https://www.oreilly.co.jp//books/9784873118635/#errata0

