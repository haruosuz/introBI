#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### Exploring Dataframes with dplyr
#' **8.3.12　dplyrによるデータフレームの探索**
#' 
d <- read.csv("Dataset_S1.txt")
colnames(d)[12] <- "percent.GC"
d$cent <- d$start >= 25800000 & d$end <= 29700000
d$diversity <- d$Pi / (10*1000) # rescale, removing 10x and making per bp
d$position <- (d$end + d$start) / 2
d$GC.binned <- cut(d$percent.GC, breaks=5)

#install.packages("dplyr") # install dplyr if it's not already installed
library(dplyr)
d_df <- tbl_df(d)
d_df

select(d_df, start, end, Pi, Recombination, depth)
select(d_df, start:total.Bases)
select(d_df, -(start:cent))

filter(d_df, Pi > 16, percent.GC > 80)

arrange(d_df, depth)
arrange(d_df, desc(total.SNPs), desc(depth))

d_df <- select(d_df, -diversity) # remove our earlier diversity column
d_df <- mutate(d_df, diversity = Pi/(10*1000))
d_df

d_df %>% mutate(GC.scaled = scale(percent.GC)) %>%
  filter(GC.scaled > 4, depth > 4) %>%
  select(start, end, depth, GC.scaled, percent.GC) %>%
  arrange(desc(depth))

help('%>%')

mtfs <- read.delim("motif_recombrates.txt", header=TRUE, stringsAsFactors=TRUE)

mtfs_df <- tbl_df(mtfs)

mtfs_df %>% group_by(chr)

mtfs_df %>%
  group_by(chr) %>%
  summarize(max_recom = max(recom), mean_recom = mean(recom), num=n())

?n_distinct()
?nth() #first() #last()

mtfs_df %>%
  group_by(chr) %>%
  summarize(max_recom = max(recom), mean_recom = mean(recom), num=n()) %>%
  arrange(desc(max_recom))


