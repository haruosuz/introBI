args <- commandArgs(TRUE)
print(args)

# we can execute a script in batch mode from the command line with:
# Rscript --vanilla my_analysis.R