#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' - https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r
#' 
#' ### Loading Data into R
#' **8.3.1　データをRに読み込ませる**
getwd()
#setwd("~/bds-files/chapter-08-r") # path to this chapter's directory in the Github repository.
#' 
#' ----------
#' 
#' **LARGE GENOMICS DATA INTO R: COLCLASSES, COMPRESSION, AND MORE**
# read.table(file, colClasses = "NULL", nrows = -1)
# fread {data.table}
#' 
#' ----------
#' 
#help(read.table)
d <- read.csv("Dataset_S1.txt")
#' [R now uses a `stringsAsFactors = FALSE` default](https://stat.ethz.ch/R-manual/R-devel/doc/html/NEWS.html)
#' 
#' Table 8-4. Commonly used read.csv() and read.delim() arguments
#' 
#' ----------
#' 
#' **GETTING DATA INTO SHAPE**
#' 
#' Table 8-5. A gene expression counts table by tissue in wide format
#' 
#' Table 8-6. A gene expression counts table by tissue in long format
#' 
#' - http://had.co.nz/reshape/
#' 
#' ----------
#' 
#' ### Exploring and Transforming Dataframes
#' **8.3.2　データフレームの探索と変換**

head(d, n=3)

nrow(d)
ncol(d)
dim(d)

colnames(d) # row.names(d)

colnames(d)[12] # original name
colnames(d)[12] <- "percent.GC"
colnames(d)[12] # after change

#' > ###### Creating Dataframes from Scratch
x <- sample(1:50, 300, replace=TRUE)
y <- 3.2*x + rnorm(300, 0, 40)
d_sim <- data.frame(y=y, x=x)
#' > 

#d$depth
mean(d$depth)
summary(d$depth)

# dataframes use two indexes separated by a comma: df[row, col].
head(d[ , 1:2])
head(d[, c("start", "end")])
d[1, c("start", "end")]
d[1, ]
d[2, 3]

#' > ###### Fragile Code and Accessing Rows and Columns in Dataframes

head(d[, "start", drop=FALSE])

#' - https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r

d$cent <- d$start >= 25800000 & d$end <= 29700000

table(d$cent)

sum(d$cent)

d$diversity <- d$Pi / (10*1000) # rescale, removing 10x and making per bp
summary(d$diversity)

#' ### Exploring Data Through Slicing and Dicing: Subsetting Dataframes
#' **8.3.3　スライシングとダイシングによるデータの探索：データフレームのサブセット化**

summary(d$total.SNPs)

#d$total.SNPs >= 85

d[d$total.SNPs >= 85, ]

d[d$Pi > 16 & d$percent.GC > 80, ]

d[d$Pi > 16 & d$percent.GC > 80, c("start", "end", "depth", "Pi")]

d[d$Pi > 16 & d$percent.GC > 80, c("start", "end", "Pi", "depth")]

#d$percent.GC[d$Pi > 16]

summary(d$depth[d$percent.GC >= 80])
summary(d$depth[d$percent.GC < 80])

sum(d$percent.GC >= 80)

summary(d$Pi[d$cent])
summary(d$Pi[!d$cent])

#d$Pi > 3
#which(d$Pi > 3)

which(d$Pi > 10)[1:4]

d[which.min(d$total.Bases),]
d[which.max(d$depth),]

#d[d$Pi > 16 & d$percent.GC > 80, ]
subset(d, Pi > 16 & percent.GC > 80)

subset(d, Pi > 16 & percent.GC > 80, c(start, end, Pi, percent.GC, depth))
