#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Developing Workflows with R Scripts
#' **8.4　Rスクリプトによるワークフロー開発**
#' 
#' ### Control Flow: if, for, and while
#' **8.4.1　制御フロー：if、for、while**
#' 
#' > ###### Iterating over Vectors
#' 
vec <- rnorm(3)
seq_along(vec)
seq_along(numeric(0)) # numeric(0) returns an empty numeric vector
seq_len(length.out = 3)
#' > 

x <- c(-3, 1, -5, 2)
ifelse(x < 0, -1, 1)

#' ### Working with R Scripts
#' **8.4.2　Rスクリプトによる作業**
source("my_analysis.R")

system(command="Rscript --vanilla my_analysis.R")

system(command="Rscript --vanilla args.R arg1 arg2 arg3")

#' > ###### Reproducibility with Knitr and Rmarkdown
#' > 
#' 
#' > ###### Reproducibility and sessionInfo()
sessionInfo()
#' > 
#' 
#' ### Workflows for Loading and Combining Multiple Files
#' **8.4.3　複数ファイルの読み込みと結合のためのワークフロー**

list.files("hotspots", pattern="hotspots.*\\.bed")

hs_files <- list.files("hotspots", pattern="hotspots.*\\.bed", full.names=TRUE)
hs_files

bedcols <- c("chr", "start", "end")
loadFile <- function(x) read.delim(x, header=FALSE, col.names=bedcols)
hs <- lapply(hs_files, loadFile)
head(hs[[1]])

names(hs) <- list.files("hotspots", pattern="hotspots.*\\.bed")

hsd <- do.call(rbind, hs)
head(hsd)
row.names(hsd) <- NULL

loadFile <- function(x) {
  # read in a BED file, extract the chromosome name from the file,
  # and add it as a column
  df <- read.delim(x, header=FALSE, col.names=bedcols)
  df$chr_name <- sub("hotspots_([^\\.]+)\\.bed", "\\1", basename(x))
  df$file <- x
  df
}

hs_files[[1]]
basename(hs_files[[1]])

hs <- lapply(hs_files, loadFile)
head(hs[[1]])

loadAndSummarizeFile <- function(x) {
  df <- read.table(x, header=FALSE, col.names=bedcols)
  data.frame(chr=unique(df$chr), n=nrow(df), mean_len=mean(df$end - df$start))
}

chr_hs_summaries <- lapply(hs_files, loadAndSummarizeFile)
chr_hs_summaries[1:2]

do.call(rbind, chr_hs_summaries)

#' ### Exporting Data
#' **8.4.4　データのエクスポート**

mtfs <- read.delim(file="motif_recombrates.txt", header=TRUE, stringsAsFactors=TRUE)

write.table(x=mtfs, file="hotspot_motifs.txt", quote=FALSE, 
            sep="\t", row.names=FALSE, col.names=TRUE)

hs_gzf <- gzfile("hotspot_motifs.txt.gz")
write.table(x=mtfs, file=hs_gzf, quote=FALSE, sep="\t", row.names=FALSE, col.names=TRUE)

tmp <- list(vec=rnorm(4), df=data.frame(a=1:3, b=3:5))
save(tmp, file="example.Rdata")
rm(tmp) # remove the original 'tmp' list
load(file="example.Rdata") # this fully restores the 'tmp' list from file
str(tmp)

?save.image()
?savehistory()

#' ## Further R Directions and Resources
#' **8.5　さらなるRの道筋とリソース**
#' 
#' - https://github.com/haruosuz/books/tree/master/r4ds
#' R for Data Science http://r4ds.had.co.nz | Rではじめるデータサイエンス
#' - https://github.com/haruosuz/books/tree/master/r4all
#' Getting Started with R, Second Edition | Rをはじめよう生命科学のためのRStudio入門
#' - https://www2.slideshare.net/antiplastics/tidy-239579849
#' バイオインフォ分野におけるtidyなデータ解析の最新動向
