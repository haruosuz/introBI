#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r
#' 
#' - [統計の落とし穴と蜘蛛の糸 - Smart Lab Life - 羊土社](https://www.yodosha.co.jp/smart-lab-life/statics_pitfalls/index.html)
#'   - [第1回 データ解析の第一歩は計算ではない](https://www.yodosha.co.jp/smart-lab-life/statics_pitfalls/statics_pitfalls01.html)
#' 探索的データ解析（EDA：exploratory data analysis）
#'   - [第2回 データの位置とばらつきを可視化しよう](https://www.yodosha.co.jp/smart-lab-life/statics_pitfalls/statics_pitfalls02.html)
#'   - [第3回 データのふるまいをモデル化する](https://www.yodosha.co.jp/smart-lab-life/statics_pitfalls/statics_pitfalls03.html)
#'   
#' ## Getting Started with R and RStudio
#' **8.1　RとRStudio入門**
#' 
#' https://github.com/vsbuffalo/bds-files/blob/master/chapter-08-r/README.md#rstudio-resources
#' ![](https://raw.githubusercontent.com/vsbuffalo/bds-files/master/chapter-08-r/rstudio-image.png)
#' 
#' ----------
#' 
#' **THE COMPREHENSIVE R ARCHIVE NETWORK (CRAN)**
#options(repos="https://cran.ism.ac.jp/")  
#install.packages("ggplot2")
#' 
#' ----------
#' 
#' ## R Language Basics
#' **8.2　R言語の基礎**
#' 
#' ### Simple Calculations in R, Calling Functions, and Getting Help in R
#' **8.2.1　Rにおける簡単な計算、関数の呼び出し、ヘルプの取得**
4 + 3
4 - 3
4 * 3
4 / 3

3 + 4/2 
(3 + 4)/2

sqrt(3.5)

#' *Table 8-1. Common mathematic functions*
#' 
#' ----------
#' 
#' **SIGNIFICANT DIGITS, PRINT(), AND OPTIONS IN R**
print(sqrt(3.5), digits=10)
getOption('digits')
options(digits=9)

round(sqrt(3.5))
help(round)
round(sqrt(3.5), digits=3)
round(sqrt(3.5), 3)
#' 
#' ----------
#' 
#' ----------
#' 
#' GETTING HELP IN R
help(log)
?log

help('+')
help(Quotes)

help.search("cross tabulate")
??"cross tabulate"

example(log)

library(help="base")
apropos("norm")
#' 
#' ----------
#' 
#' ### Variables and Assignment
#' **8.2.2　変数と代入**

# variable ----------
x <- 3.1
x
(x + 2)/2
exp(x)
y<-exp(2*x)-1
y

ls()
search()

#' > ###### RStudio Assignment Operator Shortcut
#' > 
#' 
#' ### Vectors, Vectorization, and Indexing
#' **8.2.3　ベクトル、ベクトル化、添字指定**

# vector ----------
length(3.1)

x <- c(56, 95.3, 0.4)
x
y <- c(3.2, 1.1, 0.2)
y

# vectorization ----------
x + y
x - y
x/y

seq(3, 5)
1:5

# recycle ----------
x
x - 3
x / 2

c(1, 2) + c(0, 0, 0, 0)
c(1, 2) + c(0, 0, 0)

sqrt(x)
round(sqrt(x), 3)
log(x)/2 + 1 # note how we can combined vectorized operations

# indexing ----------
x <- c(56, 95.3, 0.4)
x[2]
x[1]
x[4]
x[3] <- 0.5
x

b <- c(a=3.4, b=5.4, c=0.4)
b

names(b)
names(b) <- c("x", "y", "z") # change these names
b

b['x']
b['z']

# subsetting ----------
x[c(2, 3)]

z <- c(3.4, 2.2, 0.4, -0.4, 1.2)
z[3:5] # extract third, fourth, and fifth elements

#' > ###### Out-of-Range Indexing  
z[c(2, 1, 10)] 
#' > 

z[c(-4, -5)] # exclude fourth and fifth elements

#' > ###### Negative Indexes and the Colon Operator
-2:4
-(2:4)
#' > 

z[c(3, 2, 4, 5, 1)]

z[5:1]

order(z)
z[order(z)]
order(z, decreasing=TRUE)
z[order(z, decreasing=TRUE)]

z[c(2, 2, 1, 4, 5, 4, 3)]

set.seed(0) # we set the random number seed so this example is reproducible
i <- sample(length(z), replace=TRUE)
i
z[i]

v <- c(2.3, 6, -3, 3.8, 2, -1.1)
v == 6
v <= -3
abs(v) > 5

# Example 8-1
v[c(TRUE, TRUE, FALSE, TRUE, FALSE, FALSE)]
v[v > 2]

v > 2 & v < 4
v[v > 2 & v < 4]

#' *Table 8-2. R’s comparison and logical operators*
#' 
#' #### Vector types
#' **8.2.3.1 ベクトル型**
#' 
#' - Numeric
#' - Integer
#' - Character
#' - Logical
#' 
#' *Table 8-3. R’s vector types*
#' 
#' ----------
#' 
#' R’S SPECIAL VALUES  
NA
NULL
-Inf
Inf
NaN

#' 
#' ----------
#' 
#' > ###### Type Coercion in R  
#' > 
#' 
c(4.3, TRUE, 2.1, FALSE)
c(-9L, 3.4, 1.2, 3L)
c(43L, TRUE, 3.2413341, "a string")

q <- c(2, 3.5, -1.1, 3.8)
typeof(q)

#' #### Factors and classes in R
#' **8.2.3.2 R の因子とクラス**

chr_hits <- c("chr2", "chr2", "chr3", "chrX", "chr2", "chr3", "chr3")
hits <- factor(chr_hits)
hits

levels(hits)

hits <- factor(chr_hits, levels=c("chrX", "chrY", "chr2", "chr3", "chr4"))
hits

levels(hits) <- list(chrX="chrX", chrY="chrY", chr2="chr2", chr3="chr3", chr4="chr4")
hits

table(hits)

typeof(hits)
as.integer(hits)

nums <- c(0.97, -0.7, 0.44, 0.25, -1.38, 0.08)
summary(nums)
summary(hits)

class(nums)
class(hits)
