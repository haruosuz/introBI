#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### Working with the Split-Apply-Combine Pattern
#' **8.3.11　分割－適用－結合（Split-Apply-Combine）パターンを使用する**
#' 
#' - https://www.jstatsoft.org/article/view/v040i01
#' The Split-Apply-Combine Strategy for Data Analysis | Wickham | Journal of Statistical Software
#' 
d <- read.csv("Dataset_S1.txt")
colnames(d)[12] <- "percent.GC"
# Example 8-4. Using cut() to bin GC content
d$GC.binned <- cut(d$percent.GC, breaks=5)

d_split <- split(x=d$depth, f=d$GC.binned)
str(d_split)

names(d_split)
levels(d$GC.binned)
length(d_split)
nlevels(d$GC.binned)

lapply(d_split, mean)
unlist(lapply(d_split, mean))
sapply(d_split, mean)

dpth_summ <- lapply(split(x=d$depth, f=d$GC.binned), summary)
dpth_summ

rbind(dpth_summ[[1]], dpth_summ[[2]])
cbind(dpth_summ[[1]], dpth_summ[[2]])

do.call(rbind, lapply(split(x=d$depth, f=d$GC.binned), summary))

#' > ###### Understanding do.call()  
  do.call(rnorm, list(n=4, mean=3.3, sd=4))
#' > 

tapply(X=d$depth, INDEX=d$GC.binned, FUN=mean)
aggregate(d$depth, list(gc=d$GC.binned), mean)
?by()

