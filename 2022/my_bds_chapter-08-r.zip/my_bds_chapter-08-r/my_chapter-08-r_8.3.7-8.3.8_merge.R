#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### Merging and Combining Data: Matching Vectors and Merging Dataframes
#' **8.3.7　データのマージと結合：ベクトルのマッチングとデータフレームのマージ**

c(3, 4, -1) %in% c(1, 3, 4, 8)

reps <- read.delim("chrX_rmsk.txt.gz", header=TRUE, stringsAsFactors=TRUE)
head(reps, 3)

class(reps$repClass)
levels(reps$repClass)

common_repclass <- c("SINE", "LINE", "LTR", "DNA", "Simple_repeat")
#reps[reps$repClass %in% common_repclass, ]

sort(table(reps$repClass), decreasing=TRUE)[1:5]
top5_repclass <- names(sort(table(reps$repClass), decreasing=TRUE)[1:5])
top5_repclass

match(c("A", "C", "E", "A"), c("A", "B", "A", "E"))

#' > ###### Creating These Example Datasets
#' - https://github.com/vsbuffalo/bds-files/tree/master/chapter-08-r/motif-example
#' > 

mtfs <- read.delim("motif_recombrates.txt", header=TRUE, stringsAsFactors=TRUE)
head(mtfs, 3)
rpts <- read.delim("motif_repeats.txt", header=TRUE, stringsAsFactors=TRUE)
head(rpts, 3)

mtfs$pos <- paste(mtfs$chr, mtfs$motif_start, sep="-")
rpts$pos <- paste(rpts$chr, rpts$motif_start, sep="-")
head(mtfs, 2)
head(rpts, 2)

#' - https://support.rstudio.com/hc/en-us/articles/200711853-Keyboard-Shortcuts
#' Comment/uncomment current line/selection	Ctrl+Shift+C
# dim(mtfs)
# dim(rpts)
# unique(mtfs$motif)
# unique(rpts$name)
# recm <- merge(mtfs, rpts, by.x="pos", by.y="pos"); dim(recm)
# recm <- merge(mtfs, rpts, by.x="pos", by.y="pos", all.x=TRUE); dim(recm)

table(mtfs$pos %in% rpts$pos)
table(rpts$pos %in% mtfs$pos)

i <- match(mtfs$pos, rpts$pos)

table(is.na(i))

mtfs$repeat_name <- rpts$name[i]

mtfs$repeat_name <- rpts$name[match(mtfs$pos, rpts$pos)]

head(mtfs[!is.na(mtfs$repeat_name), ], 3)

mtfs_inner <- mtfs[!is.na(mtfs $repeat_name), ]
nrow(mtfs_inner)

recm <- merge(mtfs, rpts, by.x="pos", by.y="pos")
head(recm, 2)
nrow(recm)

recm <- merge(mtfs, rpts, by.x="pos", by.y="pos", all.x=TRUE)

#' - https://r4ds.had.co.nz/relational-data.html#understanding-joins
#' 
#' ### Using ggplot2 Facets
#' **8.3.8　ggplot2ファセットの使用**

library(ggplot2)
p <- ggplot(mtfs, aes(x=dist, y=recom)) + geom_point(size=1)
p <- p + geom_smooth(method="loess", se=FALSE, span=1/10)
print(p)
#' Figure 8-10. Recombination rate by distance to sequence motif

unique(mtfs$motif)

ggplot(mtfs, aes(x=dist, y=recom)) + geom_point(size=1) + 
  geom_smooth(aes(color=motif), method="loess", se=FALSE, span=1/10)

p <- ggplot(mtfs, aes(x=dist, y=recom)) + geom_point(size=1, color="grey")
p <- p + geom_smooth(method='loess', se=FALSE, span=1/10)
p <- p + facet_wrap(~ motif)
print(p)
#' Figure 8-11. Faceting plots by motif sequence using facet_wrap()

p <- ggplot(mtfs, aes(x=dist, y=recom)) + geom_point(size=1, color="grey")
p <- p + geom_smooth(method='loess', se=FALSE, span=1/16)
p <- p + facet_grid(repeat_name ~ motif)
print(p)
#' Figure 8-12. Using facet_grid() to facet by both repeat background and motif sequence; 
#' the empty panel indicates there is no data for this particular motif/repeat combination

table(mtfs$repeat_name, mtfs$motif, useNA="ifany")

help(formula)

p <- ggplot(mtfs, aes(x=dist, y=recom)) + geom_point(size=1, color="grey")
p <- p + geom_smooth(method='loess', se=FALSE, span=1/10)
p <- p + facet_wrap( ~ motif, scales="free_y")
print(p)
#' Figure 8-13. Recombination rates around two sequence motifs, with the y-scales free

