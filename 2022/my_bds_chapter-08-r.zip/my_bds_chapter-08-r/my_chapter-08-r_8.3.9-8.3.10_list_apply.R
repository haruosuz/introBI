#' ---
#' title: "Bioinformatics Data Skills"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # Chapter 8. A Rapid Introduction to the R Language
#' **第8章. R言語入門**
#' 
#' ## Working with and Visualizing Data in R
#' **8.3　Rでのデータの扱いとその可視化**
#' 
#' ### More R Data Structures: Lists
#' **8.3.9　さらなるRデータ構造：リスト**
#' 
#is.list(mtfs)

adh <- list(chr="2L", start=14615555L, end=14618902L, name="Adh")
adh

adh[1:2]

is.list(adh[1:2])
is.list(adh[1])

adh[[2]]
adh[['start']]

adh$chr

adh$id <- "FBgn0000055"
adh$chr <- "chr2L"
adh
adh$id <- NULL # remove the FlyBase ID
adh

#' 
#' ----------
#' 
#' **Peeking into R’s Structures with str()**
z <- list(a=list(rn1=rnorm(20), rn2=rnorm(20)), b=rnorm(10))
str(z)
#' 
#' ----------
#' 
#' ### Writing and Applying Functions to Lists with lapply() and sapply()
#' **8.3.10　lapply()とsapply()関数を使って、リストに関数を適用する**
#' 
#' #### Using lapply()
#' **8.3.10.1 lapply() を使う**

set.seed(0)
ll <- list(a=rnorm(6, mean=1), b=rnorm(6, mean=4), c=rnorm(6, mean=6))
ll

lapply(ll, mean)

ll$a[3] <- NA # replace an element with a missing value
lapply(ll, mean)
lapply(ll, mean, na.rm=TRUE)

#' > ###### lapply() in Parallel  
library(parallel)
#results <- mclapply(my_samples, slowFunction)  
options(cores=3)
getOption('cores')
#' > 
#' 
#' #### Writing functions
#' **8.3.10.2 関数を書く**
meanRemoveNA <- function(x) mean(x, na.rm=TRUE)
lapply(ll, meanRemoveNA)

lapply(ll, function(x) mean(x, na.rm=TRUE))

meanRemoveNAVerbose <- function(x, warn=TRUE) {
  # A function that removes missing values when calculating the mean
  # and warns us about it.
  if (any(is.na(x)) && warn) {
    warning("removing some missing values!")
  }
  mean(x, na.rm=TRUE)
}

#lapply(ll, meanRemoveNAVerbose)
#lapply(ll, meanRemoveNAVerbose, warn=FALSE)

#' - https://support.rstudio.com/hc/en-us/articles/200711853-Keyboard-Shortcuts
#' Extract function from selection	Ctrl+Alt+X	Cmd+Option+X 
#' 
#' > ###### Function Scope
x <- 3
fun <- function(y) {
  x <- 2.3
  x + y
}
fun(x)
x
#' - https://adv-r.hadley.nz/
#' 
#' > 
#' 
#' #### Digression: Debugging R Code
#' **8.3.10.3 R コードのデバッグ**
#' 

#' 
#' #### More list apply functions: sapply() and mapply()
#' **8.3.10.4 さらなるリスト適用関数:sapply() と mapply()**
#' 
sapply(ll, function(x) mean(x, na.rm=TRUE))

ind_1 <- list(loci_1=c("T", "T"), loci_2=c("T", "G"), loci_3=c("C", "G"))
ind_2 <- list(loci_1=c("A", "A"), loci_2=c("G", "G"), loci_3=c("C", "G"))
mapply(function(a, b) length(intersect(a, b)), ind_1, ind_2)

help(intersect)

#' > ###### Other Apply Functions for Other R Data Structures 
#apply()
#sweep() 
#' > 
#' 
