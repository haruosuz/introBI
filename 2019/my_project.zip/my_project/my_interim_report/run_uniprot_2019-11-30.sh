#!/bin/bash
set -euo pipefail

# make/change/print working directory
mkdir -p $(date +%F)
cd $(date +%F)
echo; echo "# pwd - print name of current/working directory"
pwd

# Downloading *uniprot_sprot.fasta.gz* file
URL=ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
#wget -nv $URL
#curl -O $URL

# Decompressing *uniprot_sprot.fasta.gz* file
#gunzip -c `basename $URL` > `basename $URL .gz`
#gzip -dc uniprot_sprot.fasta.gz > uniprot_sprot.fasta

# Downloading *RELEASE.metalink* file that specifies MD5 checksum https://www.uniprot.org/help/metalink
#wget ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/RELEASE.metalink

# Comparing our checksum values with those in *RELEASE.metalink* file using the md5 program:
echo; echo "# MD5 checksum"
md5 uniprot_sprot.fasta.gz
grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink

echo; echo "# Release date"
#wget ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/reldate.txt
cat reldate.txt 

# Inspecting Data
echo; echo "# ls - list directory contents"
ls -lh
# https://apprize.info/data/bioinformatics/3.html
echo; echo "# There are $(grep '^>' uniprot_sprot.fasta | wc -l) entries in *uniprot_sprot.fasta* FASTA file."
# https://apprize.info/data/bioinformatics/7.html
echo; echo "# extracting lines of a file that match a pattern."
pattern="harakiri"
grep "^>" uniprot_sprot.fasta | grep -i "${pattern}"

echo; echo "# print Mac OS X operating system version information"
sw_vers
# print system information
uname -a

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

Let’s run the script in the project’s main directory `my_project/` with:

(time bash scripts/run_uniprot.sh &) >& log.$(date +%F).txt
tail -f log.$(date +%F).txt

#__COMMENT_OUT__







