Haruo Suzuki  
Last Update: 2020-01-01

----------

# UniProtKB/Swiss-Prot project
Project started 2019-10-01.

Analyzing the most abundant organisms/proteins and [plasmid](http://www.kenq.net/dic/78.html) genes in [UniProtKB/Swiss-Prot protein sequence database](https://ja.wikipedia.org/wiki/Swiss-Prot).

----------

## Project directory structures
```
uniprot_sprot/
./README.md: project documentation
./scripts/: contains Shell scripts
./data: contains sequence data in FASTA format
./analysis: contains results of data analyses
./my_interim_report/: contains my midterm report
```
See `./analysis/my.find.txt` for more details

## scripts

The shell script `scripts/run_all.sh` automatically carries out the entire steps: creating directories, downloading data, inspecting data, and running the script for reproducibility testing.

Let's run the driver script in the project's main directory `uniprot_sprot/` with:
```
cd ~/projects/data/uniprot/uniprot_sprot/
bash scripts/run_all.sh > log.txt 2>&1 &
```
This will generate the following files:
```
./data/<version>/uniprot_sprot.fasta.gz
./data/<version>/uniprot_sprot.fasta
./analysis/output.<version>.txt
```

## data

UniProtKB/Swiss-Prot Release 2019_08, 2019_10, and 2019_11 were downloaded from <ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/> into `data/`:
```
(base) ~/projects/data/uniprot/uniprot_sprot $find . -name "*.fasta.gz" | xargs ls -l
-rw-r--r-- 1 haruo staff 88780050 Oct 11 23:08 ./data/2019_08/uniprot_sprot.fasta.gz
-rw-r--r-- 1 haruo staff 88947894 Nov 30 23:28 ./data/2019_10/uniprot_sprot.fasta.gz
-rw-r--r-- 1 haruo staff 89024988 Dec 28 01:30 ./data/2019_11/uniprot_sprot.fasta.gz
```

## analysis
```
analysis/output.2019_10.txt
analysis/output.2019_11.txt
analysis/output.2019_08.txt
```

----------

## reproducibility tests
```
analysis/my.diff.2019_08.2019_10.txt
analysis/my.diff.2019_08.2019_11.txt
```

----------

## references
- https://www.ncbi.nlm.nih.gov/pubmed/29425356
Nucleic Acids Res. 2018 Mar 16;46(5):2699. doi: 10.1093/nar/gky092.
UniProt: the universal protein knowledgebase.
UniProt Consortium T1,2,3,4.
- http://www.ncbi.nlm.nih.gov/pubmed/24622611
Database (Oxford). 2014 Mar 12;2014:bau016. doi: 10.1093/database/bau016. Print 2014.
Expert curation in UniProtKB: a case study on dealing with conflicting and erroneous data.
Poux S1, Magrane M, Arighi CN, Bridge A, O'Donovan C, Laiho K; UniProt Consortium.
- http://www.ncbi.nlm.nih.gov/pubmed/20215432
Nucleic Acids Res. 2010 Jul;38(13):4207-17. doi: 10.1093/nar/gkq140. Epub 2010 Mar 9.
Transposases are the most abundant, most ubiquitous genes in nature.
Aziz RK1, Breitbart M, Edwards RA.
<https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2910039/>

![https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2910039/figure/F3/](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2910039/bin/gkq140f3a.jpg)

----------

## codes
```
# Using Pandoc to Render Markdown to HTML
filename=README.md
pandoc --from markdown --to html ${filename} > ${filename}.html
```

----------



