#!/bin/bash
#set -euo pipefail

# make/change/print working directory
#mkdir -p ./{data/${YYYY_MM},analysis/${YYYY_MM}}
#mkdir -p ./{data,analysis}
YYYY_MM=2019_08
YYYY_MM=2019_10
YYYY_MM=$(date +%F)
mkdir -p ./${YYYY_MM}
cd ${YYYY_MM}/

echo; echo "# pwd - print name of current/working directory"
pwd

# Downloading *uniprot_sprot.fasta.gz* file
URL=ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz
 #URL=ftp://ftp.ebi.ac.uk/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz
wget $URL
#curl -O $URL

# Decompressing *uniprot_sprot.fasta.gz* file
gunzip -c `basename $URL` > `basename $URL .gz`
#gzip -dc uniprot_sprot.fasta.gz > uniprot_sprot.fasta

# Downloading *RELEASE.metalink* file that specifies MD5 checksum https://www.uniprot.org/help/metalink
wget ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/RELEASE.metalink

# Comparing our checksum values with those in *RELEASE.metalink* file using the md5 program:
echo; echo "# MD5 checksum"
md5 uniprot_sprot.fasta.gz
grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink

echo; echo "# Release date"
wget ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/reldate.txt
cat reldate.txt 

# Inspecting Data
# https://github.com/haruosuz/introBI/blob/master/2019/README.md#unix-data-tools

DB=2019_08/uniprot_sprot.fasta
DB=2019_10/uniprot_sprot.fasta
DB=./uniprot_sprot.fasta

# Inspecting Data with Head and Tail
grep "^>" "${DB}" | head -n 3
grep "^>" "${DB}" | tail -n 3

# Plain-Text Data Summary Information with wc, ls, and awk
grep "^>" ${DB} | wc -l
echo; echo "# There are $(grep "^>" ${DB} | wc -l) entries in *uniprot_sprot.fasta* FASTA file."

echo; echo "# ls - list directory contents"
ls -lh

echo; echo "# extracting lines of a file that match a pattern."
pattern="plasmid"
grep "^>" "${DB}" | grep -i "${pattern}"
grep "^>" "${DB}" | grep -i "${pattern}" | wc -l
grep "^>" "${DB}" | grep -i "${pattern}" | cut -d"=" -f2 | cut -d" " -f1,2 | sort | uniq -c
grep "^>" "${DB}" | grep -i "${pattern}" | grep "Zea mays"

# https://github.com/haruosuz/uniprot_sprot
grep '^>' $DB | perl -ne '$_=~/^>(\S+) (.+) OS=(.+?) (GN|PE)=/; print "$1 | $2 | $3\n";' | head

# Most abundant organisms
grep '^>' $DB | perl -ne '$_=~/^>(\S+) (.+) OS=(.+?) (GN|PE)=/; print "$3\n";' | \
 sort | uniq -c | sort -nr | head -20 | sed s/^/$'\t'/g

# Most abundant functions
grep '^>' $DB | perl -nle '$_=~/^>(\S+) (.+) OS=(.+?) (GN|PE)=/; print "$2";' | \
 sort | uniq -c | sort -nr | head -20 | sed s/^/$'\t'/g

echo; echo "# print Mac OS X operating system version information"
sw_vers
# print system information
uname -a

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

https://github.com/haruosuz/introBI/tree/master/2019
https://github.com/haruosuz/introBI/blob/master/2019/CaseStudy.md#uniprot_sprot
https://github.com/haruosuz/introBI/blob/master/2019/CaseStudy.md#assignment-10

# ----------
Let's run the driver script in the project's main directory with:

(time bash scripts/run_uniprot_sprot.sh &) >& log.$(date +%F).txt

#__COMMENT_OUT__

