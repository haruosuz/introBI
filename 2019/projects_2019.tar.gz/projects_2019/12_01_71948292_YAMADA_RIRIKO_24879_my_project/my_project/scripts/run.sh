#!/bin/bash
set -euo pipefail

# *uniprot_sprot.fasta.gz*ファイルをダウンロードする
# download *uniprot_sprot.fasta.gz* file with `wget` or `curl`
#curl -O ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
 wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz

# "RELEASE.metalink"ファイルをダウンロードする
# download "RELEASE.metalink" file that specifies MD5 checksum https://www.uniprot.org/help/metalink
wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/RELEASE.metalink

# MD5チェックサムを計算し、"RELEASE.metalink"ファイルの値と比較する
# compare our checksum values with those in "RELEASE.metalink" using the md5 program:
md5 uniprot_sprot.fasta.gz
grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink

# `gunzip`コマンドでファイルを展開する
# decompress files with the command `gunzip`
gunzip -c uniprot_sprot.fasta.gz > uniprot_sprot.fasta

cd ./data/
pwd
ls -lh
grep "^>" uniprot_sprot.fasta | head -n 3
grep "^>" uniprot_sprot.fasta | tail -n 3
grep "^>" uniprot_sprot.fasta | wc -l



 wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
