----------

Terumi Akamatsu  
Last Update: 2019-12-17  

----------

# my Project
Project started 2019-12-17.  
uniprot/swissprotを用いた*Ideonella Sakaiensis*の持つPET分解酵素の検索

# data
The data was downloaded by the script below on 2019-12-17:
```
wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
gunzip -c uniprot_sprot.fasta.gz > uniprot_sprot.fasta
```


## Project directories

    plastic/
     README.md: project documentation
     data/: contains data files
     scripts/: contains general project-wide scripts
     analysis/: contains results of data analyses

## Scripts

The shell script `scripts/run.sh` carries on entire steps; creating directories, downloading data, and analysing data.

Let's run this (in the `plastic/` directory) using:

    bash scripts/run.sh

----------
