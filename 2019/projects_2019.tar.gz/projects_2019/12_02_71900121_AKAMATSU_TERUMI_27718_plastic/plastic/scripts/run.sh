#!/bin/bash
set -euo pipefail

# change directory
mkdir data/uniprot/uniprot_sprot
cd data/uniprot/uniprot_sprot

# *uniprot_sprot.fasta.gz*ファイルをダウンロードする
wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz


# "RELEASE.metalink"ファイルをダウンロードする
wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/RELEASE.metalink

# MD5チェックサムを計算し、"RELEASE.metalink"ファイルの値と比較する
md5 uniprot_sprot.fasta.gz
grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink

# `gunzip`コマンドでファイルを展開する
# decompress files with the command `gunzip`
gunzip -c uniprot_sprot.fasta.gz > uniprot_sprot.fasta


# 解析
grep "^>" uniprot_sprot.fasta | grep -i "Poly(ethylene terephthalate)"
grep "^>" uniprot_sprot.fasta | grep -i "Mono(2-hydroxyethyl) terephthalate"

# done
echo "successfully finished!"
