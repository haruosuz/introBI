#!/bin/bash
set -euo pipefail

wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
gunzip uniprot_sprot.fasta.gz
grep "^>" uniprot_sprot.fasta | grep -i --color "transformer" > output.txt
