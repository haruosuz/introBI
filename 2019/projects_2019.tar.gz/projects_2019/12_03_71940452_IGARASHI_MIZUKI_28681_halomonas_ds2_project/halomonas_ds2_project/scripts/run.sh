#!/bin/bash
set -euo pipefail

mkdir data result

# download data
cd data/
wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
gunzip uniprot_sprot.fasta.gz
cd ..

grep "^>" data/uniprot_sprot.fasta | grep -i -c "Halomonas"
grep -i "^>" data/uniprot_sprot.fasta |grep -i "Halomonas"| cut -d"=" -f2 | cut -d" " -f1,2 | sort | uniq -c > result/$(date +%F)_output.txt
