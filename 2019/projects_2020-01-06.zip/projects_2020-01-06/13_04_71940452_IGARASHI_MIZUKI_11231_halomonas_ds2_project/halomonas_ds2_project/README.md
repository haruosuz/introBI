----------

Mizuki Igarashi  
Last Update: 2020-01-05  

----------

# halomonas_ds2_project Project
このプロジェクトは2019-11-18に始まりました。
プロジェクトディレクトリ、プロジェクト書類、シェルスクリプトで構成されています。

## Project directories
    halomonas_ds2_project/
     README.md: プロジェクト書類
     scripts/: プロジェクトを実行するシェルスクリプトを含みます。
     年_月_日_時/
      data/: データファイルを格納します。
      result/: データ解析の結果を含みます。

## Scripts
シェルスクリプト`scripts/run.sh`は、`年_月_日_時/`、`年_月_日_時/data/`、`年_月_日_時/result/`のディレクトリを作成し、`年_月_日_時/data/`ディレクトリ内に`uniprot_sprot.fasta`をダウンロードします。また、標準出力をファイル(`年_月_日_時/result/output.txt`)にリダイレクトします。

`halomonas_ds2_project Project/`の中で
```
bash scripts/run.sh
```
を使い、解析を実行しましょう。

## Reproducibility
解析を次の環境下`Linux ccx02 4.4.0-170-generic #199-Ubuntu SMP Thu Nov 14 01:45:04 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux`で、2020年1月5日の17時と22時に行いました。出力されたファイルの内容に差は見られませんでした。
また、別の環境下`Darwin pc.local 18.7.0 Darwin Kernel Version 18.7.0: Sun Dec  1 18:59:03 PST 2019; root:xnu-4903.278.19~1/RELEASE_X86_64 x86_64`でも解析を行いましたが、異なる環境下で出力されたファイルの内容に差は見られませんでした。

----------
