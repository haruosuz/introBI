# read library
library("seqinr")

# read downloaded data
Ideonella_Sakaiensis <- read.fasta(file ="../data/A0A0K8P6T7.fasta")[[1]];
Aequorivita_sp <- read.fasta(file="../data/A0A330MQ60.fasta")[[1]];
Bacterium_HR29 <- read.fasta(file="../data/A0A2H5Z9R5.fasta")[[1]];

# Comparing these seqences using dotPlot
pdf("result.pdf")
dotPlot(Ideonella_Sakaiensis, Aequorivita_sp)
dotPlot(Ideonella_Sakaiensis, Bacterium_HR29)
dotPlot(Aequorivita_sp, Bacterium_HR29)
dev.off()
