set -euo pipefail

# change directory
cd ..
mkdir -p data
mkdir -p analysis/$(date +%F)
cd data

# download files
wget -nc https://www.uniprot.org/uniprot/A0A0K8P6T7.fasta
wget -nc https://www.uniprot.org/uniprot/A0A330MQ60.fasta
wget -nc https://www.uniprot.org/uniprot/A0A2H5Z9R5.fasta
cd ../scripts

# run R script file and move result file
Rscript run_R.R
mv result.pdf ../analysis/$(date +%F)

# done
echo "done"
