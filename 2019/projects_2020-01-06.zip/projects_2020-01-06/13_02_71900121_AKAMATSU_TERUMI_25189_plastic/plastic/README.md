Terumi Akamatsu  
Last Update: 2020-01-04

-------------------------

# Plastic Project  
Project started 2019-12-17  
This project analyzes the homology among Poly(ethylene terephthelate) hydrolase of *ideonella sakaiensis*, that of *Aequorivita sp.*, and that of *bacterium HR29*, these are registered with Uniprot/Swissprot.  
You need to install R and seqinR packages to execute this project.

## data
The data is downloaded by the script below:
```
wget https://www.uniprot.org/uniprot/A0A0K8P6T7.fasta
wget https://www.uniprot.org/uniprot/A0A330MQ60.fasta
wget https://www.uniprot.org/uniprot/A0A2H5Z9R5.fasta
```

A0A0K8P6T7: *ideonellasakaiensis*  
A0A330MQ60: *Aequorivita sp.*  
A0A2H5Z9R5: *bacterium HR29*  

## Project directories

	plastic/
	 README.md: project documentation
	 data/: contains data files
	 scripts/: contains general project-wide scripts
	 analysis: contains results of data analysis

## Scripts

The shell script 'scripts/run.sh' carries on entire steps; creating directories, downloading data, and analysing data.  
Let's run this in the 'plastic/' directory using:

	bash scripts/run.sh

## Reproducibility

- Linux ccx02 4.4.0-170-generic #199-Ubuntu SMP Thu Nov 14 01:45:04 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux  
  R version 3.2.3  
  2020-01-03 21:10
- Linux DESKTOP-F5HT8KN 4.4.0-17763-Microsoft #864-Microsoft Thu Nov 07 15:22:00 PST 2019 x86_64 x86_64 x86_64 GNU/Linux  
  R version 3.4.4  
  2020-01-04 10:35  
The results of this project on these environment were consistent
