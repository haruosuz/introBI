----------

Ai Onoue
Last Update: 2019_1_5


----------

# Pikachurin Project

This was a data analysis of picaturin.


## Project directories

    pikachurin/
     README.md: project documentation
     data/: contains data files
     scripts/: contains general project-wide scripts
     analysis/: contains results of data analyses

## Scripts

The shell script `scripts/run.sh` creates directories (`data/`) and some empty files (`data/input.txt`).

Let's run this (in the `pikachurin/` directory) using:

    bash scripts/run.sh


##result

bash-5.0$ date
2019年 12月26日 木曜日 15時43分59秒 JST
bash-5.0$ uname -a
Darwin mcmac06.sfc.keio.ac.jp 17.7.0 Darwin Kernel Version 17.7.0: Sun Jun  2 20:31:42 PDT 2019; root:xnu-4570.71.46~1/RELEASE_X86_64 x86_64
```
bash-5.0$
bash-5.0$
bash-5.0$ # MD5チェックサムを計算し、"RELEASE.metalink"ファイルの値と比較する
bash-5.0$ # compare our checksum values with those in "RELEASE.metalink" using the md5 program:
bash-5.0$ md5 uniprot_sprot.fasta.gz
MD5 (uniprot_sprot.fasta.gz) = fd47a9a89fcf310c49a0f001b107987b
bash-5.0$ grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink
  <file name="uniprot_sprot.fasta.gz">
      <size>89024988</size>
      <verification>
        <hash type="md5">fd47a9a89fcf310c49a0f001b107987b</hash>
bash-5.0$
bash-5.0$ # `gunzip`コマンドでファイルを展開する
bash-5.0$ # decompress files with the command `gunzip`
bash-5.0$ gunzip -c uniprot_sprot.fasta.gz > uniprot_sprot.fasta
bash-5.0$
bash-5.0$
bash-5.0$ #result
bash-5.0$ pwd
/home/t18185ao/CNSiMac/data
bash-5.0$ ls -lh
total 715989
-rw-r--r--  1 t18185ao  student-mac   7.9K 12 26 15:36 RELEASE.metalink
-rw-r--r--  1 t18185ao  student-mac   265M 12 26 15:36 uniprot_sprot.fasta
-rw-r--r--  1 t18185ao  student-mac    85M 12 26 15:36 uniprot_sprot.fasta.gz
bash-5.0$ grep "^>" uniprot_sprot.fasta | head -n 3
>sp|Q6GZX4|001R_FRG3G Putative transcription factor 001R OS=Frog virus 3 (isolate Goorha) OX=654924 GN=FV3-001R PE=4 SV=1
>sp|Q6GZX3|002L_FRG3G Uncharacterized protein 002L OS=Frog virus 3 (isolate Goorha) OX=654924 GN=FV3-002L PE=4 SV=1
>sp|Q197F8|002R_IIV3 Uncharacterized protein 002R OS=Invertebrate iridescent virus 3 OX=345201 GN=IIV3-002R PE=4 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | tail -n 3
>sp|Q88470|Z_TACVF RING finger protein Z OS=Tacaribe virus (strain Franze-Fernandez) OX=928313 GN=Z PE=1 SV=3
>sp|A9JR22|Z_TAMVU RING finger protein Z OS=Tamiami mammarenavirus (isolate Rat/United States/W 10777/1964) OX=45223 GN=Z PE=3 SV=1
>sp|B2ZDY1|Z_WWAVU RING finger protein Z OS=Whitewater Arroyo mammarenavirus (isolate Rat/United States/AV 9310135/1995) OX=46919 GN=Z PE=3 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | wc -l
  561568
bash-5.0$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin"
>sp|A3KN33|EGFLA_BOVIN Pikachurin OS=Bos taurus OX=9913 GN=EGFLAM PE=2 SV=1
>sp|Q63HQ2|EGFLA_HUMAN Pikachurin OS=Homo sapiens OX=9606 GN=EGFLAM PE=1 SV=2
>sp|Q4VBE4|EGFLA_MOUSE Pikachurin OS=Mus musculus OX=10090 GN=Egflam PE=1 SV=1
>sp|B4F785|EGFLA_RAT Pikachurin OS=Rattus norvegicus OX=10116 GN=Egflam PE=2 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin" | wc -l
       4
```
bash-3.2$ date
2020年 1月 5日 日曜日 10時53分23秒 JST
bash-3.2$ uname -a
Darwin AinoMacBook-puro.local 18.6.0 Darwin Kernel Version 18.6.0: Thu Apr 25 23:16:27 PDT 2019; root:xnu-4903.261.4~2/RELEASE_X86_64 x86_64

```
bash-3.2$ bash
bash-3.2$ mkdir -p ./{data,analysis}
bash-3.2$
bash-3.2$ #data,/se
bash-3.2$ cd /Users/ai/Desktop/pikachurin_project/data
bash-3.2$ wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/uniprot_sprot.fasta.gz
bash: wget: command not found
bash-3.2$
bash-3.2$
bash-3.2$ # "RELEASE.metalink"ファイルをダウンロードする
bash-3.2$ # download "RELEASE.metalink" file that specifies MD5 checksum https://www.uniprot.org/help/metalink
bash-3.2$
bash-3.2$ wget ftp://ftp.uniprot.org/pub/databases/uniprot/knowledgebase/RELEASE.metalink
bash: wget: command not found
bash-3.2$
bash-3.2$
bash-3.2$ # MD5チェックサムを計算し、"RELEASE.metalink"ファイルの値と比較する
bash-3.2$ # compare our checksum values with those in "RELEASE.metalink" using the md5 program:
bash-3.2$ md5 uniprot_sprot.fasta.gz
md5: uniprot_sprot.fasta.gz: No such file or directory
bash-3.2$ grep -A 3 'file name="uniprot_sprot.fasta.gz"' RELEASE.metalink
grep: RELEASE.metalink: No such file or directory
bash-3.2$
bash-3.2$ # `gunzip`コマンドでファイルを展開する
bash-3.2$ # decompress files with the command `gunzip`
bash-3.2$ gunzip -c uniprot_sprot.fasta.gz > uniprot_sprot.fasta
gunzip: can't stat: uniprot_sprot.fasta.gz (uniprot_sprot.fasta.gz.gz): No such file or directory
bash-3.2$
bash-3.2$
bash-3.2$ #result
bash-3.2$ pwd
/Users/ai/Desktop/pikachurin_project/data
bash-3.2$ ls -lh
total 0
drwxr-xr-x  2 ai  staff    64B  1  5 11:04 analysis
drwxr-xr-x  2 ai  staff    64B  1  5 11:04 data
-rw-r--r--  1 ai  staff     0B  1  5 11:05 uniprot_sprot.fasta
bash-3.2$ grep "^>" uniprot_sprot.fasta | head -n 3
bash-3.2$ grep "^>" uniprot_sprot.fasta | tail -n 3
bash-3.2$ grep "^>" uniprot_sprot.fasta | wc -l
       0
bash-3.2$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin"
bash-3.2$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin" | wc -l
       0
bash-3.2$
bash-3.2$
bash-3.2$ #done
bash-3.2$ echo "successfully fintshed!"


```
