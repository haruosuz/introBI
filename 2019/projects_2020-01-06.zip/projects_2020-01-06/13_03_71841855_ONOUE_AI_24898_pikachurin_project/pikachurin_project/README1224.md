----------

Ai Onoue
Last Update: 2019_12_24


----------

# Pikachurin Project

This was a data analysis of picaturin.


## Project directories

    pikachurin/
     README.md: project documentation
     data/: contains data files
     scripts/: contains general project-wide scripts
     analysis/: contains results of data analyses

## Scripts

The shell script `scripts/run.sh` creates directories (`data/`) and some empty files (`data/input.txt`).

Let's run this (in the `pikachurin/` directory) using:

    bash scripts/run.sh


##result
```
uniprot_sprot.fasta | head -n 3
>sp|Q6GZX4|001R_FRG3G Putative transcription factor 001R OS=Frog virus 3 (isolate Goorha) OX=654924 GN=FV3-001R PE=4 SV=1
>sp|Q6GZX3|002L_FRG3G Uncharacterized protein 002L OS=Frog virus 3 (isolate Goorha) OX=654924 GN=FV3-002L PE=4 SV=1
>sp|Q197F8|002R_IIV3 Uncharacterized protein 002R OS=Invertebrate iridescent virus 3 OX=345201 GN=IIV3-002R PE=4 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | tail -n 3
grep "^>" uniprot_sprot.fasta | wc -l
grep "^>" uniprot_sprot.fasta | grep -i "pikachurin"
grep "^>" uniprot_sprot.fasta | grep -i "pikachurin" | wc -l

>sp|Q88470|Z_TACVF RING finger protein Z OS=Tacaribe virus (strain Franze-Fernandez) OX=928313 GN=Z PE=1 SV=3
>sp|A9JR22|Z_TAMVU RING finger protein Z OS=Tamiami mammarenavirus (isolate Rat/United States/W 10777/1964) OX=45223 GN=Z PE=3 SV=1
>sp|B2ZDY1|Z_WWAVU RING finger protein Z OS=Whitewater Arroyo mammarenavirus (isolate Rat/United States/AV 9310135/1995) OX=46919 GN=Z PE=3 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | wc -l
  561356
bash-5.0$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin"
>sp|A3KN33|EGFLA_BOVIN Pikachurin OS=Bos taurus OX=9913 GN=EGFLAM PE=2 SV=1
>sp|Q63HQ2|EGFLA_HUMAN Pikachurin OS=Homo sapiens OX=9606 GN=EGFLAM PE=1 SV=2
>sp|Q4VBE4|EGFLA_MOUSE Pikachurin OS=Mus musculus OX=10090 GN=Egflam PE=1 SV=1
>sp|B4F785|EGFLA_RAT Pikachurin OS=Rattus norvegicus OX=10116 GN=Egflam PE=2 SV=1
bash-5.0$ grep "^>" uniprot_sprot.fasta | grep -i "pikachurin" | wc -l
       4
```

----------
