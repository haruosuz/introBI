----------

Ririko Yamada
Last Update: 2019-12-27

----------

# serotonin project
Project started 2019-12-24.  

This is an example of a project directory, project documentation, and shell script.

## Project directories

    hoge1/
     README.md: project documentation
     data/: contains data files
     scripts/: contains general project-wide scripts
     analysis/: contains results of data analyses

## Scripts

The shell script `scripts/run.sh` creates directories (`data/` and `analysis/`) and some empty files (`data/input.txt`), and redirecting standard out to a file (`analysis/output.txt`).

Let's run this (in the `hoge1/` directory) using:

    bash scripts/run.sh
    cd my_project/
    grep "serotonin" uniprot_sprot.fasta | wc -l
    grep "serotonin" uniprot_sprot.fasta 


----------
2019-12-24 Ririko Yamada
Result
>sp|Q6EPG8|ASMT1_ORYSJ Acetylserotonin O-methyltransferase 1 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT1 PE=1 SV=1
>sp|Q8VWJ6|ASMT2_ORYSJ Acetylserotonin O-methyltransferase 2 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT2 PE=1 SV=1
>sp|Q8VWG4|ASMT3_ORYSJ Acetylserotonin O-methyltransferase 3 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT3 PE=1 SV=1
>sp|Q9T003|ASMT_ARATH Acetylserotonin O-methyltransferase OS=Arabidopsis thaliana OX=3702 GN=ASMT PE=1 SV=1
>sp|P10950|ASMT_BOVIN Acetylserotonin O-methyltransferase OS=Bos taurus OX=9913 GN=ASMT PE=1 SV=2
>sp|Q92056|ASMT_CHICK Acetylserotonin O-methyltransferase OS=Gallus gallus OX=9031 GN=ASMT PE=2 SV=1
>sp|P46597|ASMT_HUMAN Acetylserotonin O-methyltransferase OS=Homo sapiens OX=9606 GN=ASMT PE=1 SV=1
>sp|Q8HZJ0|ASMT_MACMU Acetylserotonin O-methyltransferase OS=Macaca mulatta OX=9544 GN=ASMT PE=2 SV=1
>sp|D3KU66|ASMT_MOUSE Acetylserotonin O-methyltransferase OS=Mus musculus OX=10090 GN=Asmt PE=2 SV=1
>sp|D3KU67|ASMT_MUSMM Acetylserotonin O-methyltransferase OS=Mus musculus molossinus OX=57486 GN=Asmt PE=2 SV=1
>sp|B3GSH5|ASMT_RAT Acetylserotonin O-methyltransferase OS=Rattus norvegicus OX=10116 GN=Asmt PE=1 SV=1
>sp|Q9XT49|SC6A4_BOVIN Sodium-dependent serotonin transporter OS=Bos taurus OX=9913 GN=SLC6A4 PE=2 SV=1
>sp|O35899|SC6A4_CAVPO Sodium-dependent serotonin transporter OS=Cavia porcellus OX=10141 GN=SLC6A4 PE=2 SV=1
>sp|P51905|SC6A4_DROME Sodium-dependent serotonin transporter OS=Drosophila melanogaster OX=7227 GN=SerT PE=2 SV=1
>sp|P31645|SC6A4_HUMAN Sodium-dependent serotonin transporter OS=Homo sapiens OX=9606 GN=SLC6A4 PE=1 SV=1
>sp|Q9MYX0|SC6A4_MACMU Sodium-dependent serotonin transporter OS=Macaca mulatta OX=9544 GN=SLC6A4 PE=2 SV=1
>sp|Q60857|SC6A4_MOUSE Sodium-dependent serotonin transporter OS=Mus musculus OX=10090 GN=Slc6a4 PE=1 SV=4
>sp|P31652|SC6A4_RAT Sodium-dependent serotonin transporter OS=Rattus norvegicus OX=10116 GN=Slc6a4 PE=1 SV=1

2019-12-27 Ririko Yamada
Result
Last login: Fri Dec 27 11:32:05 on ttys000
%  bash scripts/run.sh
bash: scripts/run.sh: No such file or directory
cd my_project/
grep "serotonin" uniprot_sprot.fasta | wc -l
grep "serotonin" uniprot_sprot.fasta 

%     cd my_project/
%     grep "serotonin" uniprot_sprot.fasta | wc -l

18
%     grep "serotonin" uniprot_sprot.fasta 
>sp|Q6EPG8|ASMT1_ORYSJ Acetylserotonin O-methyltransferase 1 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT1 PE=1 SV=1
>sp|Q8VWJ6|ASMT2_ORYSJ Acetylserotonin O-methyltransferase 2 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT2 PE=1 SV=1
>sp|Q8VWG4|ASMT3_ORYSJ Acetylserotonin O-methyltransferase 3 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT3 PE=1 SV=1
>sp|Q9T003|ASMT_ARATH Acetylserotonin O-methyltransferase OS=Arabidopsis thaliana OX=3702 GN=ASMT PE=1 SV=1
>sp|P10950|ASMT_BOVIN Acetylserotonin O-methyltransferase OS=Bos taurus OX=9913 GN=ASMT PE=1 SV=2
>sp|Q92056|ASMT_CHICK Acetylserotonin O-methyltransferase OS=Gallus gallus OX=9031 GN=ASMT PE=2 SV=1
>sp|P46597|ASMT_HUMAN Acetylserotonin O-methyltransferase OS=Homo sapiens OX=9606 GN=ASMT PE=1 SV=1
>sp|Q8HZJ0|ASMT_MACMU Acetylserotonin O-methyltransferase OS=Macaca mulatta OX=9544 GN=ASMT PE=2 SV=1
>sp|D3KU66|ASMT_MOUSE Acetylserotonin O-methyltransferase OS=Mus musculus OX=10090 GN=Asmt PE=2 SV=1
>sp|D3KU67|ASMT_MUSMM Acetylserotonin O-methyltransferase OS=Mus musculus molossinus OX=57486 GN=Asmt PE=2 SV=1
>sp|B3GSH5|ASMT_RAT Acetylserotonin O-methyltransferase OS=Rattus norvegicus OX=10116 GN=Asmt PE=1 SV=1
>sp|Q9XT49|SC6A4_BOVIN Sodium-dependent serotonin transporter OS=Bos taurus OX=9913 GN=SLC6A4 PE=2 SV=1
>sp|O35899|SC6A4_CAVPO Sodium-dependent serotonin transporter OS=Cavia porcellus OX=10141 GN=SLC6A4 PE=2 SV=1
>sp|P51905|SC6A4_DROME Sodium-dependent serotonin transporter OS=Drosophila melanogaster OX=7227 GN=SerT PE=2 SV=1
>sp|P31645|SC6A4_HUMAN Sodium-dependent serotonin transporter OS=Homo sapiens OX=9606 GN=SLC6A4 PE=1 SV=1
>sp|Q9MYX0|SC6A4_MACMU Sodium-dependent serotonin transporter OS=Macaca mulatta OX=9544 GN=SLC6A4 PE=2 SV=1
>sp|Q60857|SC6A4_MOUSE Sodium-dependent serotonin transporter OS=Mus musculus OX=10090 GN=Slc6a4 PE=1 SV=4
>sp|P31652|SC6A4_RAT Sodium-dependent serotonin transporter OS=Rattus norvegicus OX=10116 GN=Slc6a4 PE=1 SV=1


2019-12-27 yamamotokunnnoMacbok Pro 
Result
yamamotofirippunoMacBook-Pro:Desktop phillipyamamoto$ grep "serotonin" uniprot_sprot.fasta | wc -l
grep "serotonin" uniprot_sprot.fasta
18
yamamotofirippunoMacBook-Pro:Desktop phillipyamamoto$ grep "serotonin" uniprot_sprot.fasta
>sp|Q6EPG8|ASMT1_ORYSJ Acetylserotonin O-methyltransferase 1 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT1 PE=1 SV=1
>sp|Q8VWJ6|ASMT2_ORYSJ Acetylserotonin O-methyltransferase 2 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT2 PE=1 SV=1
>sp|Q8VWG4|ASMT3_ORYSJ Acetylserotonin O-methyltransferase 3 OS=Oryza sativa subsp. japonica OX=39947 GN=ASMT3 PE=1 SV=1
>sp|Q9T003|ASMT_ARATH Acetylserotonin O-methyltransferase OS=Arabidopsis thaliana OX=3702 GN=ASMT PE=1 SV=1
>sp|P10950|ASMT_BOVIN Acetylserotonin O-methyltransferase OS=Bos taurus OX=9913 GN=ASMT PE=1 SV=2
>sp|Q92056|ASMT_CHICK Acetylserotonin O-methyltransferase OS=Gallus gallus OX=9031 GN=ASMT PE=2 SV=1
>sp|P46597|ASMT_HUMAN Acetylserotonin O-methyltransferase OS=Homo sapiens OX=9606 GN=ASMT PE=1 SV=1
>sp|Q8HZJ0|ASMT_MACMU Acetylserotonin O-methyltransferase OS=Macaca mulatta OX=9544 GN=ASMT PE=2 SV=1
>sp|D3KU66|ASMT_MOUSE Acetylserotonin O-methyltransferase OS=Mus musculus OX=10090 GN=Asmt PE=2 SV=1
>sp|D3KU67|ASMT_MUSMM Acetylserotonin O-methyltransferase OS=Mus musculus molossinus OX=57486 GN=Asmt PE=2 SV=1
>sp|B3GSH5|ASMT_RAT Acetylserotonin O-methyltransferase OS=Rattus norvegicus OX=10116 GN=Asmt PE=1 SV=1
>sp|Q9XT49|SC6A4_BOVIN Sodium-dependent serotonin transporter OS=Bos taurus OX=9913 GN=SLC6A4 PE=2 SV=1
>sp|O35899|SC6A4_CAVPO Sodium-dependent serotonin transporter OS=Cavia porcellus OX=10141 GN=SLC6A4 PE=2 SV=1
>sp|P51905|SC6A4_DROME Sodium-dependent serotonin transporter OS=Drosophila melanogaster OX=7227 GN=SerT PE=2 SV=1
>sp|P31645|SC6A4_HUMAN Sodium-dependent serotonin transporter OS=Homo sapiens OX=9606 GN=SLC6A4 PE=1 SV=1
>sp|Q9MYX0|SC6A4_MACMU Sodium-dependent serotonin transporter OS=Macaca mulatta OX=9544 GN=SLC6A4 PE=2 SV=1
>sp|Q60857|SC6A4_MOUSE Sodium-dependent serotonin transporter OS=Mus musculus OX=10090 GN=Slc6a4 PE=1 SV=4
>sp|P31652|SC6A4_RAT Sodium-dependent serotonin transporter OS=Rattus norvegicus OX=10116 GN=Slc6a4 PE=1 SV=1

On 2019/12/27 11:43, Ririko Yamada wrote:
> grep "serotonin" uniprot_sprot.fasta | wc -l
> grep "serotonin" uniprot_sprot.fasta 
