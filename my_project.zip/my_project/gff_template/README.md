Yukichi Fukuzawa  
Last Update: 2050-03-31  

---

# Some genome project
Project started 2001-04-01.  

A complete genome of some organisim was retrieved from the NCBI FTP site.
Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
./README.md
./analysis/
./data/
./scripts/run.sh
```

----------

## scripts

The shell script `scripts/run.sh` automatically carries out the entire steps: creating directories, downloading data, and inspecting data.

Let's run the shell script `scripts/run.sh` in the project's main directory with:
```
(bash scripts/run.sh &) >& log.$(date +%F).txt
```

----------

## data

Some organism, Complete Genome (GenBank accession starting with GCA) data were downloaded on 2001-04-01 into `data/`

### MD5 checksum
```
md5
md5sum
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to count how many of each feature (column 3 in .gff).

```
cat output.txt
```

There were *N* genes in some organism, complete genome. 
Similar results were reported in previous studies.

----------

## reproducibility

This workflow is fully reproducible.
I confirmed that this workflow run on different machines yielded the same outcome using:
```
diff output.txt output.txt 
```

### environments

Print operating system characteristics using:
```
uname -a
```

----------

## references
- https://github.com/haruosuz/introBI/tree/main/2025-10
- https://github.com/haruosuz/introBI/blob/main/CaseStudy.md#ncbi-datasets

----------
