Haruo Suzuki  
Last Update: 2024-09-30

----------

# NCBI GENOME_REPORTS Project
Project started 2020-10-17.  

Lists of genome sequencing projects for eukaryotes, prokaryotes (archaea and bacteria), and mobile genetic elements (viruses and plasmids) were retrieved from the NCBI FTP site.

## Project directories
```
ncbi_genome_reports/
 README.md: project documentation 
 data/: contains lists of genome sequence data
 scripts/: contains shell scripts
 analysis/: contains results of data analyses
```

----------

## scripts

The shell script `scripts/run_ncbi_GENOME_REPORTS.sh` automatically carries out the entire steps: creating directories, downloading data files, and inspecting data (generating the output file *output.txt*).

Let's run the driver script in the project's main directory `ncbi_genome_reports/` with:
```
(time bash scripts/run_ncbi_GENOME_REPORTS.sh &) >& log.$(date +%F).txt
```

----------

## data

Data downloaded on 2024-09-30 from <https://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/> into `data/`:

## analysis

```
$cat analysis/2024-09-30/output.txt 
   37955 eukaryotes.txt
   87889 overview.txt
   59427 plasmids.txt
     121 prok_reference_genomes.txt
    5682 prok_representative_genomes.txt
  729609 prokaryotes.txt
   86877 viruses.txt
 1007560 total
```

## environment
```
uname -a
#sw_vers

$uname -a
Darwin MacBook-Pro-14-inch-2021.local 21.2.0 Darwin Kernel Version 21.2.0: Sun Nov 28 20:28:41 PST 2021; root:xnu-8019.61.5~1/RELEASE_ARM64_T6000 arm64

# Mac OS X operating system version information
$sw_vers
ProductName:	macOS
ProductVersion:	12.1
BuildVersion:	21C52
```

## References
- http://bonohu.jp/blog/genome-list.html
- 2015 ["Update on RefSeq microbial genomes resources."](http://www.ncbi.nlm.nih.gov/pubmed/25510495)
