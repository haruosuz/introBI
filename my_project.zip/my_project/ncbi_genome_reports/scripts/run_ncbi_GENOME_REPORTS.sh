#!/bin/bash
set -euo pipefail

echo; echo "[$(date)] $0 job has been started."

# Creating directories
TODAY=$(date +%F)
mkdir -p {analysis/${TODAY},data/${TODAY},scripts}
cd data/${TODAY}

# Downloading data
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/{README,*.txt}

# Inspecting data
ls -lh *.txt > output.txt
wc -l *.txt >> output.txt
mv output.txt ../../analysis/${TODAY}

cd ../..
find .

# Print operating system characteristics
uname -a
#sw_vers

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

(time bash scripts/run_ncbi_GENOME_REPORTS.sh &) >& log.$(date +%F).txt

#__COMMENT_OUT__
