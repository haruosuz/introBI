Yukichi Fukuzawa  
Last Update: 2025-10-13  

---

# Mycoplasma genitalium (mgen) genome project
Project started 2025-10-13.  

Mycoplasma genitalium G37, complete genome (GCA_000027325.1)
was retrieved from the NCBI FTP site.
Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
$find . -type f | sort
./README.md
./analysis/2025-10-13/output.txt
./data/2025-10-13/GCA_000027325.1_ASM2732v1_genomic.gff
./data/2025-10-13/md5checksums.txt
./log.2025-10-13.txt
./scripts/run.sh
```

----------

## scripts

The shell script `scripts/run.sh` automatically carries out the entire steps: creating directories, downloading data, and inspecting data.

Let's run the shell script `scripts/run.sh` in the project's main directory with:
```
(bash scripts/run.sh &) >& log.$(date +%F).txt
```

----------

## data

Mycoplasma genitalium G37, complete genome (GCA_000027325.1)
data were downloaded on 2025-10-13 into `data/`

### MD5 checksum
```
110e60f8c963ee967c0e21aa3dd96b6c  GCA_000027325.1_ASM2732v1_genomic.gff.gz
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to count how many of each feature (column 3 in .gff).

```
$cat analysis/2025-10-13/output.txt 
 476 CDS
  43 exon
 519 gene
   6 pseudogene
   3 rRNA
   2 region
  38 sequence_alteration
  36 tRNA
   4 transcript
```

There were 476 CDS, 3 rRNA, 36 tRNA in the genome.
Similar results were reported in previous studies.
https://pmc.ncbi.nlm.nih.gov/articles/PMC549432/table/tbl1/

----------

## reproducibility

This workflow is fully reproducible.
I confirmed that this workflow run on different machines yielded the same outcome using:
```
diff analysis/2025-10-13/output.txt analysis/2025-10-13/output.txt
```

### environments

Print operating system characteristics using:
```
$uname -a
Darwin MacBook-Pro-14-inch-2021.local 24.6.0 Darwin Kernel Version 24.6.0: Mon Jul 14 11:30:29 PDT 2025; root:xnu-11417.140.69~1/RELEASE_ARM64_T6000 arm64
```

----------

## references
- https://github.com/haruosuz/introBI/tree/main/2025-10
- https://github.com/haruosuz/introBI/blob/main/CaseStudy.md#ncbi-datasets
- https://pmc.ncbi.nlm.nih.gov/articles/PMC549432/table/tbl1/

----------
