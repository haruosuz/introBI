Haruo Suzuki  
Last Update: 2025-10-13  

---

# *Escherichia coli* (ecoli) genome project
Project started 2025-10-13.  

A complete genome of *Escherichia coli* K-12 was retrieved from the NCBI FTP site.
Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
$find . -type f | sort
./README.md
./analysis/2025-10-13/output.txt
./data/2025-10-13/GCA_000005845.2_ASM584v2_genomic.gff
./data/2025-10-13/md5checksums.txt
./log.2025-10-13.txt
./scripts/run.sh
```

----------

## scripts

The shell script `scripts/run.sh` automatically carries out the entire steps: creating directories, downloading data, and inspecting data.

Let's run the shell script `scripts/run.sh` in the project's main directory with:
```
(bash scripts/run.sh &) >& log.$(date +%F).txt
```

----------

## data

Escherichia coli str. K-12 substr. MG1655, Complete Genome (GCA_000005845.2) data were downloaded on 2025-10-13 into `data/`

### MD5 checksum
```
MD5 (GCA_000005845.2_ASM584v2_genomic.gff.gz) = 2cf36acdffcfe56474c1d80f3ae92a40
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to count how many of each feature (column 3 in .gff).

```
find analysis -name "output.txt" | tail -n 2
find analysis -name "output.txt" | tail -n 2 | xargs wc -l
find analysis -name "output.txt" | tail -n 2 | xargs head -n 11

==> analysis/2025-10-13/output.txt <==
4340 CDS
 216 exon
4506 gene
  50 mobile_genetic_element
 108 ncRNA
   1 origin_of_replication
 145 pseudogene
  22 rRNA
   1 region
  48 sequence_feature
  86 tRNA
```

There were 4340 CDS, 86 tRNA and 22 rRNA genes in Escherichia coli str. K-12 substr. MG1655, complete genome. 
Similar results were reported by
[Sharp et al. (2005)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/table/tbl1/).
[Sharp et al. (2005)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/) stated that "species exposed to selection for rapid growth have more rRNA operons, more tRNA genes and more strongly selected codon usage bias."

----------

## reproducibility

This workflow is fully reproducible.
I confirmed that this workflow run on different machines yielded the same outcome using:
```
find analysis -name "output.txt" | tail -n 2 | xargs diff
```

### environments

Print operating system characteristics using:
```
$uname -a
Darwin MacBook-Pro-14-inch-2021.local 24.6.0 Darwin Kernel Version 24.6.0: Mon Jul 14 11:30:29 PDT 2025; root:xnu-11417.140.69~1/RELEASE_ARM64_T6000 arm64
```

----------

## references
- https://github.com/haruosuz/introBI/tree/main/2025-10
  - https://github.com/haruosuz/introBI/blob/main/2025-10/README.md#using-pandoc-to-render-markdown-to-html
```
FILE=README.md
pandoc --from markdown --to html ${FILE} > ${FILE}.html
```
- [Sharp et al. (2005) Nucleic Acids Res "Variation in the strength of selected codon usage bias among bacteria"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/)
  - [Table 1
The 80 bacterial genome sequences analysed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/table/tbl1/)

----------
