Haruo Suzuki  
Last Update: 2024-05-12  

----------

# template1 project
Project started 2015-11-18.  

This is an example of a project directory, project documentation, and shell script.

## Project directories
```
template1/README.md: Project documentation
template1/analysis: Contains output files
template1/data: Contains input files
template1/scripts: Contains files documenting program code
```

## Scripts

The shell script `scripts/run.sh` creates directories (`data/` and `analysis/`) and some empty files (`data/input.txt`), and redirecting standard out to a file (`analysis/output.txt`).

Let's run this (in the `template1/` directory) using:

    bash scripts/run.sh

----------
