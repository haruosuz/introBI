#!/bin/bash
set -euo pipefail

echo; echo "[$(date)] $0 job has been started."

echo; echo "# Creating directories"
TODAY=$(date +%F)
mkdir -p analysis/$TODAY data/$TODAY scripts
cd data/$TODAY

echo; echo "# Downloading data..."
BASE_URL=https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/009/858/895/GCA_009858895.3_ASM985889v3/
wget ${BASE_URL}/md5checksums.txt
URL=${BASE_URL}/GCA_009858895.3_ASM985889v3_genomic.gff.gz
wget "$URL"

echo; echo "# Verifying MD5 checksum..."
if command -v md5sum &>/dev/null; then md5sum *.gz; else md5 *.gz; fi
grep "_genomic.gff.gz" *md5checksums.txt

echo; echo "# Decompressing files..."
gunzip *.gz

echo; echo "# Inspecting GFF file..."
GFF=$(basename "$URL" .gz)
# Using grep, cut, sort, uniq to summarize columns of data
grep -v "^#" "$GFF" | cut -f3 | sort | uniq -c >> ../../analysis/$TODAY/output.txt

echo; echo "# Print operating system characteristics"
uname -a

echo; echo "[$(date)] $0 has been successfully completed."
