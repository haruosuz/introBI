Haruo Suzuki  
Last Update: 2025-10-13

---

# SARS-CoV-2 genome project
Project started 2025-10-13.

Severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) isolate Wuhan-Hu-1, complete genome
was retrieved from the NCBI FTP site.
Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
$find . -type f | sort
./README.md
./analysis/2025-10-13/output.txt
./data/2025-10-13/GCA_009858895.3_ASM985889v3_genomic.gff
./data/2025-10-13/md5checksums.txt
./log.2025-10-13.txt
./scripts/run.sh
```

----------

## scripts

The shell script `scripts/run.sh` automatically carries out the entire steps: creating directories, downloading data, and inspecting data.

Let's run the shell script `scripts/run.sh` in the project's main directory with:
```
(bash scripts/run.sh &) >& log.$(date +%F).txt
```

----------

## data

Severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) isolate Wuhan-Hu-1, complete genome
were downloaded on 2025-10-13 into `data/`

### MD5 checksum
```
$md5 md5checksums.txt
MD5 (md5checksums.txt) = d1bb63f930b6fd09f0a232156a8f0489

$md5sum md5checksums.txt 
d1bb63f930b6fd09f0a232156a8f0489  md5checksums.txt
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to count how many of each feature (column 3 in .gff).

```
cat ./analysis/2025-10-13/output.txt
  11 CDS
   1 five_prime_UTR
  10 gene
   1 region
   1 three_prime_UTR
```

There were 11 CDS in Severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) isolate Wuhan-Hu-1, complete genome.

----------

## reproducibility

This workflow is fully reproducible.
I confirmed that this workflow run on different machines yielded the same outcome using:
```
diff analysis/2025-10-13/output.txt analysis/2025-10-13/output.txt
```

### environments

Print operating system characteristics using:
```
uname -a
```

----------

## references
- https://github.com/haruosuz/introBI/tree/main/2025-10
- https://github.com/haruosuz/introBI/blob/main/CaseStudy.md#ncbi-datasets

----------
