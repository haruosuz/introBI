Haruo Suzuki  
Last Update: 2020-12-10

---

# *Escherichia coli* (ecoli) genome project
Project started 2020-12-08.  

A complete genome of *Escherichia coli* K-12 was retrieved from the NCBI FTP site. Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
$find ecoli -type f | sort
ecoli/README.md
ecoli/README.md.html
ecoli/analysis/2020-12-08/output.txt
ecoli/analysis/2020-12-09/output.txt
ecoli/analysis/2020-12-10/output.txt
ecoli/data/2020-12-08/GCA_000005845.2_ASM584v2_genomic.fna
ecoli/data/2020-12-08/GCA_000005845.2_ASM584v2_genomic.gff
ecoli/data/2020-12-08/md5checksums.txt
ecoli/data/2020-12-09/GCA_000005845.2_ASM584v2_genomic.fna
ecoli/data/2020-12-09/GCA_000005845.2_ASM584v2_genomic.gff
ecoli/data/2020-12-09/md5checksums.txt
ecoli/data/2020-12-10/GCA_000005845.2_ASM584v2_genomic.fna
ecoli/data/2020-12-10/GCA_000005845.2_ASM584v2_genomic.gff
ecoli/data/2020-12-10/md5checksums.txt
ecoli/log.2020-12-08.txt
ecoli/log.2020-12-09.txt
ecoli/log.2020-12-10.txt
ecoli/scripts/run.sh
```

----------

## scripts

The shell script `scripts/run.sh` automatically carries out the entire steps: creating directories, downloading data, and inspecting data.

Let's run the shell script `scripts/run.sh` in the project's main directory with:
```
(bash scripts/run.sh &) >& log.$(date +%F).txt
```

----------

## data

Escherichia coli str. K-12 substr. MG1655, Complete Genome (GCA_000005845.2) data were downloaded on 2020-12-08, 2020-12-09, and 2020-12-10 into `data/`

### MD5 checksum
```
MD5 (GCA_000005845.2_ASM584v2_genomic.fna.gz) = 7e69874199f23fd21b060dc0b2b72321
MD5 (GCA_000005845.2_ASM584v2_genomic.gff.gz) = e63aeebf410a358f02a1e5144d1367e7
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to print FASTA header lines (begin with `>` in .fna) and count how many of each feature (column 3 in .gff).

```
$cat analysis/2020-12-08/output.txt
$cat analysis/2020-12-09/output.txt
$cat analysis/2020-12-10/output.txt

>U00096.3 Escherichia coli str. K-12 substr. MG1655, complete genome
4379 CDS
 180 exon
4419 gene
  49 mobile_genetic_element
  72 ncRNA
   1 origin_of_replication
 166 pseudogene
  22 rRNA
   1 recombination_feature
   1 region
 697 repeat_region
  48 sequence_feature
  86 tRNA
```

There were 4379 CDS, 86 tRNA and 22 rRNA genes in Escherichia coli str. K-12 substr. MG1655, complete genome. 
Similar results were reported by
[Sharp et al. (2005)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/table/tbl1/).
[Sharp et al. (2005)](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/) stated that "species exposed to selection for rapid growth have more rRNA operons, more tRNA genes and more strongly selected codon usage bias."

----------

## reproducibility

This workflow is fully reproducible.
I confirmed that this workflow run on different machines yielded the same outcome using:
```
diff analysis/2020-12-08/output.txt analysis/2020-12-09/output.txt
diff analysis/2020-12-08/output.txt analysis/2020-12-10/output.txt
diff analysis/2020-12-09/output.txt analysis/2020-12-10/output.txt
```

### environments

Print operating system characteristics using:
```
uname -a
sw_vers

1)
Darwin haruos-MacBook-Pro-US.local 19.6.0 Darwin Kernel Version 19.6.0: Thu Oct 29 22:56:45 PDT 2020; root:xnu-6153.141.2.2~1/RELEASE_X86_64 x86_64
ProductName:	Mac OS X
ProductVersion:	10.15.7
BuildVersion:	19H15

2)
Darwin haruos-MacBook-Pro-US.local 18.7.0 Darwin Kernel Version 18.7.0: Thu Jun 20 18:42:21 PDT 2019; root:xnu-4903.270.47~4/RELEASE_X86_64 x86_64 i386 MacBookPro15,2 Darwin
ProductName:    Mac OS X
ProductVersion: 10.14.6
BuildVersion:   18G87

3)
Darwin haruonoMacBook-Pro.local 18.7.0 Darwin Kernel Version 18.7.0: Tue Aug 20 16:57:14 PDT 2019; root:xnu-4903.271.2~2/RELEASE_X86_64 x86_64
ProductName:	Mac OS X
ProductVersion:	10.14.6
BuildVersion:	18G95
```

----------

## references
- [DATA SCIENCE FOR BIOINFORMATICS [DS2] 2020](https://github.com/haruosuz/introBI/tree/master/2020)
  - [NCBI Genome List](https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list)
  - [Using Pandoc to Render Markdown to HTML](https://github.com/haruosuz/introBI/tree/master/2020#using-pandoc-to-render-markdown-to-html)

		FILE=README.md
		pandoc --from markdown --to html ${FILE} > ${FILE}.html

- [Sharp et al. (2005) Nucleic Acids Res "Variation in the strength of selected codon usage bias among bacteria"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/)
  - [Table 1
The 80 bacterial genome sequences analysed](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC549432/table/tbl1/)
