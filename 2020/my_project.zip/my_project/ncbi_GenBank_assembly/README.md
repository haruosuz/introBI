Haruo Suzuki  
Last Update: 2020-11-16

---

# *Escherichia coli* genome project
Project started 2020-11-03.  

Retrieving genome information from <http://www.ncbi.nlm.nih.gov/genome/browse/>

## Genome and Annotation Data

Escherichia coli str. K-12 substr. MG1655, Complete Genome (GCA_000005845.2) data were downloaded on Fri Nov  6 19:38:54 JST 2020 using:
```
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.fna.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.gff.gz
#wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt -O GCA_000005845.2_ASM584v2_md5checksums.txt
```

## MD5 checksum
```
MD5 (GCA_000005845.2_ASM584v2_genomic.fna.gz) = 7e69874199f23fd21b060dc0b2b72321
MD5 (GCA_000005845.2_ASM584v2_genomic.gff.gz) = e63aeebf410a358f02a1e5144d1367e7
```

----------

## Unix commands

### Running Bash scripts
```
(bash scripts/run_ncbi_GenBank_assembly.sh &) >& log.$(date +%F).txt
```

### Using Pandoc to Render Markdown to HTML
```
pandoc --from markdown --to html README.md > README.md.html
```

----------

## References
- [DATA SCIENCE FOR BIOINFORMATICS [DS2] 2020](https://github.com/haruosuz/introBI/tree/master/2020)
    - [NCBI Genome List](https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list)

----------
