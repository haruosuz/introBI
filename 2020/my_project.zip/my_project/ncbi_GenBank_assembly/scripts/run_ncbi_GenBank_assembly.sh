#!/bin/bash
set -e
set -u
set -o pipefail

echo; echo "[$(date)] $0 job has been started."

cd data/

# Downloading data
# Escherichia coli str. K-12 substr. MG1655
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.fna.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.gff.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt
#wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt -O GCA_000005845.2_ASM584v2_md5checksums.txt

echo; echo "## MD5 checksum"
md5 *.gz
grep "_genomic.fna.gz" *_md5checksums.txt
grep "_genomic.gff.gz" *_md5checksums.txt

# decompress files with the command `gunzip`:
gunzip *.gz

# Done
echo; echo "[$(date)] $0 has been successfully completed."


