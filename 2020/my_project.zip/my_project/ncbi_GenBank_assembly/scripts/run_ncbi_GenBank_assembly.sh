#!/bin/bash
set -e
set -u
set -o pipefail

echo; echo "[$(date)] $0 job has been started."

# Creating directories
mkdir -p {data/$(date +%F),scripts,analysis}
cd data/$(date +%F)

# Downloading data
# Escherichia coli str. K-12 substr. MG1655
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.fna.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.gff.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt -O GCA_000005845.2_ASM584v2_md5checksums.txt

echo; echo "## MD5 checksum"
md5 *.gz
grep "_genomic.fna.gz" *_md5checksums.txt
grep "_genomic.gff.gz" *_md5checksums.txt

# Print operating system characteristics
uname -a
#sw_vers

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

(bash scripts/run_ncbi_GenBank_assembly.sh &) >& log.$(date +%F).txt

#__COMMENT_OUT__


