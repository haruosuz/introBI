Masaru Tomita  
Last Update: 2020-10-13  

---

# DATA SCIENCE FOR BIOINFORMATICS

----------
## 2020-10-20
[Managing a Bioinformatics Project](https://github.com/haruosuz/introBI/blob/master/2020/README.md#managing-a-bioinformatics-project)

----------
## assignment 2
https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#assignment-2

**タイトル**
生命科学のデータベースにおけるアノテーションの解析

生命科学の公的データベースには、配列の由来する生物名・遺伝子名・タンパク質の機能などのアノテーション（注釈）が付けられており、生命科学の研究に利用されてきた。しかし、これらのアノテーションには、誤植や表記が統一されていない（文字列に大文字と小文字が混在する）例が多数あり、これらのエラーが拡散してしまうという問題が存在する。そこで、バイオインフォマティクス・データスキルを応用して、データベースにおけるアノテーションのエラーを解析する。

**参考文献**
- [データベース | 生命科学の分野のデータベース](https://bi.biopapyrus.jp/db/)

----------
## 2020-10-13

[Setup](https://github.com/haruosuz/introBI/blob/master/2020/README.md#setup)

- Installed Homebrew, wget, Atom, Git
- Downloaded Supplementary Material https://github.com/vsbuffalo/bds-files/

----------
