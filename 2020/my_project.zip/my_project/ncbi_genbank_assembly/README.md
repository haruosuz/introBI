Haruo Suzuki  
Last Update: 2020-11-16

---

# *Escherichia coli* genome project
Project started 2020-11-03.  

A complete genome of *Escherichia coli* K-12 was retrieved from the NCBI FTP site. Unix tools (grep, cut, sort and uniq) were used to assess genome sequence features.

- [project directory structures](#project-directory-structures)
- [scripts](#scripts)
- [data](#data)
- [analysis](#analysis)
- [reproducibility](#reproducibility)
- [references](#references)

----------

## project directory structures
```
ncbi_genbank_assembly $find . | sort

./README.md
./analysis
./analysis/2020-11-15
./analysis/2020-11-15/output.txt
./analysis/2020-11-16
./analysis/2020-11-16/output.txt
./data
./data/2020-11-15
./data/2020-11-15/GCA_000005845.2_ASM584v2_genomic.fna
./data/2020-11-15/GCA_000005845.2_ASM584v2_genomic.gff
./data/2020-11-15/md5checksums.txt
./data/2020-11-16
./data/2020-11-16/GCA_000005845.2_ASM584v2_genomic.fna
./data/2020-11-16/GCA_000005845.2_ASM584v2_genomic.gff
./data/2020-11-16/md5checksums.txt
./log.2020-11-15.txt
./log.2020-11-16.txt
./scripts
./scripts/run_all.sh
./scripts/run_data_downloader.sh
./scripts/run_data_inspector.sh
```

----------

## scripts

The shell script `scripts/run_all.sh` automatically carries out the entire steps: creating directories (`data/` and `analysis/`), running the shell script for downloading data `scripts/run_data_downloader.sh`, and for inspecting data `scripts/run_data_inspector.sh` which generates the output files `analysis/output.txt`.

Let's run the driver script `scripts/run_all.sh` in the project's main directory with:
```
(bash scripts/run_all.sh &) >& log.$(date +%F).txt
```

----------

## data

Escherichia coli str. K-12 substr. MG1655, Complete Genome (GCA_000005845.2) data were downloaded on Fri Nov  6 19:38:54 JST 2020 using:
```
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.fna.gz
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/GCA_000005845.2_ASM584v2_genomic.gff.gz
#wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt
wget https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/005/845/GCA_000005845.2_ASM584v2/md5checksums.txt -O GCA_000005845.2_ASM584v2_md5checksums.txt
```

### MD5 checksum
```
MD5 (GCA_000005845.2_ASM584v2_genomic.fna.gz) = 7e69874199f23fd21b060dc0b2b72321
MD5 (GCA_000005845.2_ASM584v2_genomic.gff.gz) = e63aeebf410a358f02a1e5144d1367e7
```

----------

## analysis

Unix tools (grep, cut, sort and uniq) were used to print FASTA header lines (begin with `>` in *.fna) and count how many of each feature (column 3 in *.gff).

```
$cat analysis/output.txt
$cat analysis/2020-11-15/output.txt
$cat analysis/2020-11-16/output.txt

>U00096.3 Escherichia coli str. K-12 substr. MG1655, complete genome

4419 gene
4379 CDS
 697 repeat_region
 180 exon
 166 pseudogene
  86 tRNA
  72 ncRNA
  49 mobile_genetic_element
  48 sequence_feature
  22 rRNA
   1 region
   1 recombination_feature
   1 origin_of_replication
```

----------

## reproducibility

This workflow is fully reproducible.

I confirmed that this workflow run on different machines yielded the same outcome using:
```
$diff analysis/2020-11-15/output.txt analysis/2020-11-16/output.txt
```

### environments

1)
```
Darwin haruos-MacBook-Pro-US.local 19.6.0 Darwin Kernel Version 19.6.0: Thu Oct 29 22:56:45 PDT 2020; root:xnu-6153.141.2.2~1/RELEASE_X86_64 x86_64
ProductName:	Mac OS X
ProductVersion:	10.15.7
BuildVersion:	19H15
```

2)
```
Darwin haruos-MacBook-Pro-US.local 18.7.0 Darwin Kernel Version 18.7.0: Thu Jun 20 18:42:21 PDT 2019; root:xnu-4903.270.47~4/RELEASE_X86_64 x86_64 i386 MacBookPro15,2 Darwin
ProductName:    Mac OS X
ProductVersion: 10.14.6
BuildVersion:   18G87
```

----------

## references
- [DATA SCIENCE FOR BIOINFORMATICS [DS2] 2020](https://github.com/haruosuz/introBI/tree/master/2020)
  - [NCBI Genome List](https://github.com/haruosuz/introBI/blob/master/2020/CaseStudy.md#ncbi-genome-list)

----------


