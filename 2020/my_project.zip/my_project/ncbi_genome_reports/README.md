Haruo Suzuki  
Last Update: 2020-10-17

----------

# NCBI GENOME_REPORTS Project
Project started 2020-10-17.  

Lists of genome sequencing projects for eukaryotes, prokaryotes (archaea and bacteria), and mobile genetic elements (viruses and plasmids) were retrieved from the NCBI FTP site.

## Project directories
```
ncbi_genome_reports/
 README.md: project documentation 
 data/: contains lists of genome sequence data
 scripts/: contains shell scripts
 analysis/: contains results of data analyses
```

## Data

Data downloaded on 2020-10-17 from <ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/> into `data/`:
```
data/2020-10-17/README
data/2020-10-17/eukaryotes.txt
data/2020-10-17/overview.txt
data/2020-10-17/plasmids.txt
data/2020-10-17/prok_reference_genomes.txt
data/2020-10-17/prok_representative_genomes.txt
data/2020-10-17/prokaryotes.txt
data/2020-10-17/viruses.txt
```

## Scripts

The shell script *scripts/run_ncbi_GENOME_REPORTS.sh* automatically carries out the entire steps: creating directories, downloading data files, and inspecting data (generating the output file *analysis/output.txt*).

Let's run the driver script in the project's main directory *ncbi_genome_reports/* with:

    # bash scripts/run_ncbi_GENOME_REPORTS.sh > log.txt 2>&1 &
    (time bash scripts/run_ncbi_GENOME_REPORTS.sh &) >& log.$(date +%F).txt  

## Run environment
```
$uname -a
Darwin haruos-MacBook-Pro-US.local 18.7.0 Darwin Kernel Version 18.7.0: Thu Jun 20 18:42:21 PDT 2019; root:xnu-4903.270.47~4/RELEASE_X86_64 x86_64 i386 MacBookPro15,2 Darwin

# Mac OS X operating system version information
$sw_vers
ProductName:	Mac OS X
ProductVersion:	10.14.6
BuildVersion:	18G87
```

## References
- http://bonohu.jp/blog/genome-list.html
- 2015 ["Update on RefSeq microbial genomes resources."](http://www.ncbi.nlm.nih.gov/pubmed/25510495)


