Haruo Suzuki  
Last Update: 2020-10-22

----------

# NCBI GENOME_REPORTS Project
Project started 2020-10-17.  

Lists of genome sequencing projects for eukaryotes, prokaryotes (archaea and bacteria), and mobile genetic elements (viruses and plasmids) were retrieved from the NCBI FTP site.

## Project directories
```
ncbi_genome_reports/
 README.md: project documentation 
 data/: contains lists of genome sequence data
 scripts/: contains shell scripts
 analysis/: contains results of data analyses
```

## scripts

The shell script *scripts/run_ncbi_GENOME_REPORTS.sh* automatically carries out the entire steps: creating directories, downloading data files, and inspecting data (generating the output file *output.txt*).

Let's run the driver script in the project's main directory *ncbi_genome_reports/* with:
```
(bash scripts/run_ncbi_GENOME_REPORTS.sh &) >& log.txt
```

## data

Data downloaded on 2020-10-20 and 2020-10-22 from <ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/> into `data/`:

## analysis

```
$cat analysis/2020-10-22/output.txt 
1801 Archaea
28475 Bacteria
5945 Eukaryota
20545 Viruses

$cat analysis/2020-10-20/output.txt 
1801 Archaea
28454 Bacteria
5945 Eukaryota
20511 Viruses
```

## environment
```
$uname -a
Darwin haruos-MacBook-Pro-US.local 18.7.0 Darwin Kernel Version 18.7.0: Thu Jun 20 18:42:21 PDT 2019; root:xnu-4903.270.47~4/RELEASE_X86_64 x86_64 i386 MacBookPro15,2 Darwin

# Mac OS X operating system version information
$sw_vers
ProductName:	Mac OS X
ProductVersion:	10.14.6
BuildVersion:	18G87
```

## References
- http://bonohu.jp/blog/genome-list.html
- 2015 ["Update on RefSeq microbial genomes resources."](http://www.ncbi.nlm.nih.gov/pubmed/25510495)


