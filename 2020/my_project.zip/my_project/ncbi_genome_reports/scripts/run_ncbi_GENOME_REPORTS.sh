#!/bin/bash
set -euo pipefail

echo; echo "[$(date)] $0 job has been started."

# Creating directories
TODAY=$(date +%F)
mkdir -p {analysis/${TODAY},data/${TODAY},scripts}
cd data/${TODAY}

# Downloading data
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/GENOME_REPORTS/{README,*.txt}

# Inspecting data
ls -l *.txt
wc -l *.txt

# Using grep, cut, sort, uniq to summarize columns of data
grep -v "^#" overview.txt | cut -f2 | sort | uniq -c > output.txt
mv output.txt ../../analysis/${TODAY}

# SARS-CoV-2
echo "There are $(grep -c 'Severe acute respiratory syndrome coronavirus 2' viruses.txt) SARS-CoV-2 genomes in the viruses.txt file."
wget -O NC_045512.gbk http://togows.dbcls.jp/entry/nucleotide/NC_045512

cd ../..
find .

# Print operating system characteristics
uname -a
#sw_vers

# Done
echo; echo "[$(date)] $0 has been successfully completed."

: <<'#__COMMENT_OUT__'

bash scripts/run_ncbi_GENOME_REPORTS.sh 2>&1 | tee log.txt

bash scripts/run_ncbi_GENOME_REPORTS.sh > log.txt 2>&1 &

#__COMMENT_OUT__
